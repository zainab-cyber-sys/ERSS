
  # Replicate Design Precisely

  This is a code bundle for Replicate Design Precisely. The original project is available at https://www.figma.com/design/8ECqXehSQe256vC1JbcGjK/Replicate-Design-Precisely.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  