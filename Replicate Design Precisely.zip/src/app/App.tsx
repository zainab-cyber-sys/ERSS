import { useState, useEffect, useRef } from "react";
import { Toaster, toast } from "sonner";
import {
  ArrowLeft, Moon, Sun, Eye, EyeOff, Search, CheckCircle2, XCircle,
  Clock, AlertTriangle, FileText, Building2, Activity, Save, X,
  Loader2, ChevronRight, Bell, LogOut, User, Phone, MapPin,
  MessageSquare, Shield, Stethoscope, Siren, RefreshCw, Edit2,
  CheckCheck, ClipboardList, Send, Info, TriangleAlert,
  Video, Users, MessageSquarePlus, ArrowUpRight, CalendarClock
} from "lucide-react";
import svgPaths from "../imports/Body/svg-yg4fvv454f";

// ─── Types ────────────────────────────────────────────────────────────────────
type Theme = "light" | "dark";
type UrgencyLevel = "IMMEDIATE" | "URGENT" | "ROUTINE";
type ReferralStatus = "PENDING" | "ACCEPTED" | "DECLINED" | "IN_TRANSIT" | "COMPLETED";

type ReferralDraft = {
  // Step 1 — Patient Details
  surname: string; givenNames: string; dob: string; sex: string; address: string;
  phone: string; nin: string; nhis: string; allergies: string; currentMedications: string;
  nokName: string; nokPhone: string; nokRelationship: string;
  // Step 2 — Clinical Details
  urgency: UrgencyLevel | ""; reasonForReferral: string; specialtyNeeded: string;
  chiefComplaint: string; duration: string; historyOfPresentingIllness: string;
  provisionalDiagnosis: string; examinationFindings: string; investigations: string;
  bp: string; pulse: string; temp: string; rr: string;
  spo2: string; weight: string; height: string; muac: string;
  treatmentGiven: string; clinicianName: string; clinicianMdcn: string;
  department: string; referralDate: string;
  // Step 3 — Facility & Transport
  selectedFacilityId: string; transportMode: string; escortRequired: string;
  referralNotes: string;
};

const EMPTY_DRAFT: ReferralDraft = {
  surname: "", givenNames: "", dob: "", sex: "", address: "", phone: "",
  nin: "", nhis: "", allergies: "", currentMedications: "",
  nokName: "", nokPhone: "", nokRelationship: "",
  urgency: "", reasonForReferral: "", specialtyNeeded: "",
  chiefComplaint: "", duration: "", historyOfPresentingIllness: "",
  provisionalDiagnosis: "", examinationFindings: "", investigations: "",
  bp: "", pulse: "", temp: "", rr: "", spo2: "", weight: "", height: "", muac: "",
  treatmentGiven: "", clinicianName: "", clinicianMdcn: "", department: "",
  referralDate: new Date().toISOString().split("T")[0],
  selectedFacilityId: "", transportMode: "", escortRequired: "", referralNotes: "",
};

type Screen =
  | { id: "login" }
  | { id: "forgot-password" }
  | { id: "create-account" }
  | { id: "verify-email"; email: string }
  | { id: "account-success" }
  | { id: "dashboard" }
  | { id: "refer-patient"; step: 1 | 2 | 3 | 4 }
  | { id: "referral-submitted"; referralId: string }
  | { id: "manage-referrals" }
  | { id: "referral-detail"; referralId: string }
  | { id: "consult-inbox" }
  | { id: "consult-thread"; consultId: string }
  | { id: "new-consult" };

// ─── Mock data ────────────────────────────────────────────────────────────────
const MOCK_REFERRALS = [
  {
    id: "REF-0041",
    patient: { name: "Adaeze Okonkwo", age: 34, sex: "F", phone: "+234 803 456 7890" },
    specialty: "Cardiology",
    chiefComplaint: "Severe chest pain radiating to left arm, with diaphoresis",
    provisionalDiagnosis: "Suspected STEMI",
    urgency: "IMMEDIATE" as UrgencyLevel,
    referringFacility: "Karu PHC, Abuja",
    receivingFacility: "National Hospital Abuja",
    referringClinician: "Nurse Fatima Yusuf",
    receivedAt: "14 min ago",
    status: "ACCEPTED" as ReferralStatus,
    vitals: { bp: "180/110 mmHg", pulse: "102 bpm", temp: "37.2°C", spo2: "94%", rr: "22/min" },
    notes: "Patient has history of hypertension (on amlodipine 5mg). Aspirin 300mg and GTN spray given en route. IV access secured.",
  },
  {
    id: "REF-0039",
    patient: { name: "Babatunde Coker", age: 7, sex: "M", phone: "+234 706 234 5678" },
    specialty: "Paediatrics",
    chiefComplaint: "Febrile seizures, high-grade fever 39.8°C, 2 episodes",
    provisionalDiagnosis: "Complex febrile seizure — R/O meningitis",
    urgency: "URGENT" as UrgencyLevel,
    referringFacility: "Mararaba PHC, Nasarawa",
    receivingFacility: "University of Abuja Teaching Hospital",
    referringClinician: "Nurse Samuel Danladi",
    receivedAt: "31 min ago",
    status: "PENDING" as ReferralStatus,
    vitals: { bp: "N/A", pulse: "130 bpm", temp: "39.8°C", spo2: "96%", rr: "26/min" },
    notes: "Child had 2 seizure episodes each ~2 mins. Diazepam PR given. Parents accompanying.",
  },
  {
    id: "REF-0037",
    patient: { name: "Emmanuel Nwosu", age: 61, sex: "M", phone: "+234 811 345 6789" },
    specialty: "Neurosurgery",
    chiefComplaint: "Sudden collapse, left-sided weakness, slurred speech",
    provisionalDiagnosis: "Ischaemic CVA — R/O haemorrhagic stroke",
    urgency: "URGENT" as UrgencyLevel,
    referringFacility: "Enugu State Hospital",
    receivingFacility: "National Hospital Abuja",
    referringClinician: "Dr. Bolaji Adewale",
    receivedAt: "2h ago",
    status: "IN_TRANSIT" as ReferralStatus,
    vitals: { bp: "195/115 mmHg", pulse: "88 bpm", temp: "37.1°C", spo2: "95%", rr: "20/min" },
    notes: "GCS 12/15. Right gaze deviation. Ambulance en route.",
  },
  {
    id: "REF-0035",
    patient: { name: "Chiamaka Okoye", age: 28, sex: "F", phone: "+234 706 234 5678" },
    specialty: "Obstetrics & Gynaecology",
    chiefComplaint: "Severe headache, facial oedema, high BP at 36 weeks gestation",
    provisionalDiagnosis: "Pre-eclampsia with severe features",
    urgency: "IMMEDIATE" as UrgencyLevel,
    referringFacility: "Jabi PHC, Abuja",
    receivingFacility: "Garki Hospital Abuja",
    referringClinician: "Dr. Adaora Eze",
    receivedAt: "3h ago",
    status: "DECLINED" as ReferralStatus,
    vitals: { bp: "165/105 mmHg", pulse: "88 bpm", temp: "37.0°C", spo2: "97%", rr: "18/min" },
    notes: "Primigravida 36 weeks. Visual changes. MgSO4 prophylaxis started. Redirected — no OBS beds.",
  },
  {
    id: "REF-0033",
    patient: { name: "Mustapha Abubakar", age: 62, sex: "M", phone: "+234 803 678 9012" },
    specialty: "Endocrinology",
    chiefComplaint: "Uncontrolled blood sugar (RBS 18.4 mmol/L), leg wound not healing",
    provisionalDiagnosis: "Diabetic foot ulcer, Grade 3 (Wagner classification)",
    urgency: "ROUTINE" as UrgencyLevel,
    referringFacility: "Gwagwalada Area Council PHC",
    receivingFacility: "University of Abuja Teaching Hospital",
    referringClinician: "Dr. Ngozi Obi",
    receivedAt: "Yesterday",
    status: "COMPLETED" as ReferralStatus,
    vitals: { bp: "145/90 mmHg", pulse: "78 bpm", temp: "37.5°C", spo2: "97%", rr: "16/min" },
    notes: "Patient on metformin 500mg BD and glibenclamide 5mg OD. Wound cultured. Vascular surgery review scheduled.",
  },
];

// ─── Tele-consult types ───────────────────────────────────────────────────────
type ConsultStatus = "AWAITING" | "ACTIVE" | "RESOLVED" | "FOLLOW_UP" | "CONVERTED";
type ConsultMessage = {
  id: string; sender: "REQUESTER" | "SPECIALIST" | "SYSTEM";
  senderName: string; text: string; time: string;
};
type Consult = {
  id: string; patient: { name: string; age: number; sex: string; phone: string };
  specialty: string; pool: string; clinicalQuestion: string;
  clinicalHistory?: string; investigations?: string;
  urgency: UrgencyLevel; requestedBy: string; requestingFacility: string;
  status: ConsultStatus; createdAt: string; messages: ConsultMessage[];
  specialistAssigned?: string; closureAdvice?: string;
};

const MOCK_CONSULTS: Consult[] = [
  {
    id: "CON-0022",
    patient: { name: "Funmilayo Usman", age: 28, sex: "F", phone: "+234 706 234 5678" },
    specialty: "Obstetrics & Gynaecology", pool: "Abuja OBS/GYN Pool",
    clinicalQuestion: "28F at 36 weeks, BP 145/95 on three readings, urine protein ++, headache. Pre-eclampsia? Can we manage locally or refer?",
    clinicalHistory: "Primigravida, ANC throughout at this facility. No prior hypertension. Fetal heart sounds normal.",
    investigations: "Urine dipstick protein ++. BP ×3 over 6 hrs: 148/96, 145/95, 152/98. FBC and LFT sent.",
    urgency: "URGENT", requestedBy: "Dr. Ngozi Obi", requestingFacility: "Gwagwalada PHC",
    status: "RESOLVED", createdAt: "45 min ago",
    closureAdvice: "Manage locally — start MgSO4 + antihypertensives, plan induction. Refer only if BP unresponsive after 2 doses.",
    specialistAssigned: "Dr. Amaka Eze (OBS, UATH)",
    messages: [
      { id: "m1", sender: "REQUESTER", senderName: "Dr. Ngozi Obi", text: "28F, primigravida, 36 weeks. BP 145/95 ×3. Urine protein ++. Headache. Fetal heart sounds normal, no visual changes. Pre-eclampsia? Safe to manage here or refer?", time: "10:14 AM" },
      { id: "m2", sender: "SPECIALIST", senderName: "Dr. Amaka Eze (OBS, UATH)", text: "Yes — BP ≥140/90 with proteinuria ≥20 weeks is pre-eclampsia. At 145/95 with headache this is approaching severe features. Classify URGENT.", time: "10:18 AM" },
      { id: "m3", sender: "SPECIALIST", senderName: "Dr. Amaka Eze (OBS, UATH)", text: "Start MgSO4 loading dose 4g IV over 15 mins, then 1g/hr maintenance. Antihypertensives: labetalol 200mg PO or hydralazine 5mg IV. Monitor BP every 15 mins and fetal HR.", time: "10:19 AM" },
      { id: "m4", sender: "REQUESTER", senderName: "Dr. Ngozi Obi", text: "Starting MgSO4 loading dose now. Should we induce here or transfer to UATH?", time: "10:22 AM" },
      { id: "m5", sender: "SPECIALIST", senderName: "Dr. Amaka Eze (OBS, UATH)", text: "If BP responds and you have a theatre, manage locally — plan induction within 24–48h. If BP doesn't settle after 2 doses of antihypertensives, or visual changes/epigastric pain develop, refer immediately.", time: "10:25 AM" },
      { id: "m6", sender: "SYSTEM", senderName: "System", text: "Thread closed by Dr. Amaka Eze — Manage Locally", time: "10:28 AM" },
    ],
  },
  {
    id: "CON-0021",
    patient: { name: "Kamilu Abubakar", age: 55, sex: "M", phone: "+234 803 678 9012" },
    specialty: "Internal Medicine", pool: "Abuja Internal Medicine Pool",
    clinicalQuestion: "T2DM patient, HbA1c 11.2%, on max doses of metformin and glibenclamide. Persistent hyperglycaemia. Start insulin or refer?",
    clinicalHistory: "T2DM 8 years. Hypertension on amlodipine 5mg OD. eGFR 58 mL/min. No foot ulcers. No prior insulin use.",
    investigations: "HbA1c 11.2% (last month). RBS today 18.4 mmol/L fasting. BP 145/90. eGFR 58. Urine ACR elevated.",
    urgency: "ROUTINE", requestedBy: "Nurse Fatima Yusuf", requestingFacility: "Karu PHC",
    status: "AWAITING", createdAt: "1h ago", specialistAssigned: undefined,
    messages: [
      { id: "m1", sender: "REQUESTER", senderName: "Nurse Fatima Yusuf", text: "55M, T2DM 8 years. HbA1c 11.2% last month. Metformin 1g BD and glibenclamide 10mg OD — maximum doses. RBS today 18.4 mmol/L fasting. Fatigue, polyuria. eGFR 58.", time: "9:40 AM" },
      { id: "m2", sender: "REQUESTER", senderName: "Nurse Fatima Yusuf", text: "Hypertension on amlodipine 5mg OD, BP 145/90 today. Should we initiate insulin or is this a referral case?", time: "9:41 AM" },
    ],
  },
  {
    id: "CON-0020",
    patient: { name: "Grace Eze", age: 42, sex: "F", phone: "+234 705 567 8901" },
    specialty: "Dermatology", pool: "Abuja Dermatology Pool",
    clinicalQuestion: "Chronic pruritic annular rash on forearms and neck — 3 months, not responding to antihistamines. Ringworm vs. eczema?",
    clinicalHistory: "No known allergies. No atopy history. Works in a school.",
    investigations: "KOH preparation not available at this facility.",
    urgency: "ROUTINE", requestedBy: "Dr. Bolaji Adewale", requestingFacility: "Garki General Hospital",
    status: "RESOLVED", createdAt: "3h ago",
    closureAdvice: "Manage locally — topical clotrimazole 1% BD for 4 weeks. Review in 4 weeks; refer if no improvement.",
    specialistAssigned: "Dr. Yemi Adesanya (Derm, LUTH)",
    messages: [
      { id: "m1", sender: "REQUESTER", senderName: "Dr. Bolaji Adewale", text: "42F, 3-month itchy annular rash on both forearms and posterior neck, central clearing. Tried loratadine 10mg OD 2 weeks — no improvement. No systemic symptoms.", time: "7:22 AM" },
      { id: "m2", sender: "SPECIALIST", senderName: "Dr. Yemi Adesanya (Derm, LUTH)", text: "Annular pattern with central clearing = classic tinea corporis (ringworm), not eczema. Antihistamines won't work — needs antifungals.", time: "7:35 AM" },
      { id: "m3", sender: "SPECIALIST", senderName: "Dr. Yemi Adesanya (Derm, LUTH)", text: "Start topical clotrimazole 1% BD for 4 weeks. Avoid sharing towels/bedding. If no improvement after 4 weeks, consider oral terbinafine and refer.", time: "7:36 AM" },
      { id: "m4", sender: "REQUESTER", senderName: "Dr. Bolaji Adewale", text: "Prescribing clotrimazole now. Will review at 4 weeks.", time: "7:40 AM" },
      { id: "m5", sender: "SYSTEM", senderName: "System", text: "Thread closed by Dr. Yemi Adesanya — Manage Locally", time: "7:42 AM" },
    ],
  },
  {
    id: "CON-0019",
    patient: { name: "Babatunde Coker", age: 7, sex: "M", phone: "+234 705 567 8905" },
    specialty: "Paediatrics", pool: "Abuja Paediatrics Pool",
    clinicalQuestion: "7M, 2 febrile seizures today (39.8°C), prior episode 6 months ago. Simple or complex febrile seizures? Manage here or refer?",
    clinicalHistory: "Previous febrile seizure 6 months ago. Normal developmental milestones. No family history of epilepsy.",
    investigations: "LP: CSF clear, no RBCs, normal glucose. Blood culture sent. FBC: WBC 14.2 (neutrophilia). CRP elevated.",
    urgency: "URGENT", requestedBy: "Nurse Samuel Danladi", requestingFacility: "Mararaba PHC",
    status: "FOLLOW_UP", createdAt: "2h ago",
    closureAdvice: "Follow-up — check blood culture in 24h. EEG + neurology review outpatient in 4 weeks.",
    specialistAssigned: "Dr. Chike Nwosu (Paeds, UATH)",
    messages: [
      { id: "m1", sender: "REQUESTER", senderName: "Nurse Samuel Danladi", text: "7M, 2 febrile seizures today (39.8°C), each ~2 mins, generalised tonic-clonic. Post-ictal, now conscious. Diazepam PR 5mg given. No focal deficit.", time: "8:15 AM" },
      { id: "m2", sender: "SPECIALIST", senderName: "Dr. Chike Nwosu (Paeds, UATH)", text: "Two episodes in 24h + prior history = complex febrile seizures. Do LP to exclude meningitis, blood culture, FBC, CRP.", time: "8:28 AM" },
      { id: "m3", sender: "SPECIALIST", senderName: "Dr. Chike Nwosu (Paeds, UATH)", text: "Start empirical antibiotics (ceftriaxone 50mg/kg IV if available) while awaiting results. Paracetamol for fever.", time: "8:29 AM" },
      { id: "m4", sender: "REQUESTER", senderName: "Nurse Samuel Danladi", text: "LP done — CSF clear. Started ceftriaxone. Fever now 38.1°C. No further seizures in last 45 mins.", time: "8:45 AM" },
      { id: "m5", sender: "SPECIALIST", senderName: "Dr. Chike Nwosu (Paeds, UATH)", text: "Good. If no more seizures in next 6 hours, consider discharge on oral antibiotics pending culture. Call me directly if a 3rd seizure occurs.", time: "8:50 AM" },
      { id: "m6", sender: "SYSTEM", senderName: "System", text: "Thread closed by Dr. Chike Nwosu — Follow-up Needed", time: "8:52 AM" },
    ],
  },
];

const MOCK_FACILITIES = [
  {
    id: "NHA-001",
    name: "National Hospital Abuja",
    type: "Federal Teaching Hospital",
    state: "Abuja (FCT)",
    specialties: ["Emergency Medicine", "Cardiology", "Neurology", "Oncology", "Obstetrics & Gynaecology"],
    beds: "AVAILABLE" as const,
    distance: "4.2 km",
    phone: "+234 9 523 0105",
  },
  {
    id: "UATH-001",
    name: "University of Abuja Teaching Hospital",
    type: "State Teaching Hospital",
    state: "Abuja (FCT)",
    specialties: ["Emergency Medicine", "Paediatrics", "Orthopaedics", "General Surgery", "Internal Medicine"],
    beds: "AVAILABLE" as const,
    distance: "22 km",
    phone: "+234 9 671 0038",
  },
  {
    id: "GARKI-001",
    name: "Garki Hospital Abuja",
    type: "General Hospital",
    state: "Abuja (FCT)",
    specialties: ["Emergency Medicine", "Internal Medicine", "Obstetrics & Gynaecology", "Paediatrics"],
    beds: "LIMITED" as const,
    distance: "6.8 km",
    phone: "+234 9 234 0050",
  },
  {
    id: "LASUTH-001",
    name: "Lagos University Teaching Hospital",
    type: "Federal Teaching Hospital",
    state: "Lagos",
    specialties: ["All Specialties — Comprehensive Tertiary Care"],
    beds: "AVAILABLE" as const,
    distance: "Interstate",
    phone: "+234 1 774 5080",
  },
  {
    id: "UCH-001",
    name: "University College Hospital, Ibadan",
    type: "Federal Teaching Hospital",
    state: "Oyo",
    specialties: ["All Specialties — Comprehensive Tertiary Care"],
    beds: "AVAILABLE" as const,
    distance: "Interstate",
    phone: "+234 2 241 1768",
  },
];

// ─── Status/Urgency config ────────────────────────────────────────────────────
const URGENCY_CONFIG: Record<UrgencyLevel, { label: string; sublabel: string; badgeCls: string; dotCls: string; icon: React.ReactNode }> = {
  IMMEDIATE: {
    label: "Immediate", sublabel: "Life-threatening — patient needs care within minutes",
    badgeCls: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    dotCls: "bg-red-500", icon: <Siren size={13} />,
  },
  URGENT: {
    label: "Urgent", sublabel: "Serious — patient needs care within 2–4 hours",
    badgeCls: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    dotCls: "bg-amber-500", icon: <TriangleAlert size={13} />,
  },
  ROUTINE: {
    label: "Routine", sublabel: "Stable — can be scheduled for next available slot",
    badgeCls: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    dotCls: "bg-emerald-500", icon: <CheckCircle2 size={13} />,
  },
};

const STATUS_CONFIG: Record<ReferralStatus, { label: string; badgeCls: string; icon: React.ReactNode }> = {
  PENDING: { label: "Awaiting Response", badgeCls: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300", icon: <Clock size={12} /> },
  ACCEPTED: { label: "Accepted", badgeCls: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300", icon: <CheckCircle2 size={12} /> },
  DECLINED: { label: "Declined", badgeCls: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300", icon: <XCircle size={12} /> },
  IN_TRANSIT: { label: "Patient En Route", badgeCls: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300", icon: <Activity size={12} /> },
  COMPLETED: { label: "Completed", badgeCls: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400", icon: <CheckCheck size={12} /> },
};

const BED_CONFIG = {
  AVAILABLE: { label: "Beds available", cls: "text-emerald-600 dark:text-emerald-400" },
  LIMITED: { label: "Limited capacity", cls: "text-amber-600 dark:text-amber-400" },
  FULL: { label: "No beds available", cls: "text-red-600 dark:text-red-400" },
};

// ─── Shared primitive components ──────────────────────────────────────────────

function MediRouteLogo() {
  return (
    <div className="flex items-center gap-2.5 shrink-0">
      <div className="rounded-lg size-9 flex items-center justify-center shrink-0 bg-primary shadow-sm">
        <svg className="size-[14px]" fill="none" viewBox="0 0 13.75 13.75">
          <path d={svgPaths.p6294f90} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.4" />
        </svg>
      </div>
      <span className="font-bold text-[1.05rem] tracking-tight text-foreground">
        MediRoute <span className="font-normal text-muted-foreground">NG</span>
      </span>
    </div>
  );
}

function ThemeToggle({ theme, onToggle }: { theme: Theme; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-all min-w-[44px] min-h-[44px] flex items-center justify-center"
    >
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}

function UrgencyBadge({ level }: { level: UrgencyLevel }) {
  const cfg = URGENCY_CONFIG[level];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${cfg.badgeCls}`}>
      {cfg.icon} {cfg.label}
    </span>
  );
}

function StatusBadge({ status }: { status: ReferralStatus }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${cfg.badgeCls}`}>
      {cfg.icon} {cfg.label}
    </span>
  );
}

// Buttons
function Btn({ children, onClick, disabled, type = "button", variant = "primary", size = "md", loading = false, className = "", ...rest }: {
  children: React.ReactNode; onClick?: () => void; disabled?: boolean;
  type?: "button" | "submit"; variant?: "primary" | "secondary" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg"; loading?: boolean; className?: string; [k: string]: unknown;
}) {
  const base = "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 disabled:cursor-not-allowed";
  const sizes = { sm: "px-3 py-1.5 text-sm min-h-[36px]", md: "px-4 py-2.5 text-[0.9375rem] min-h-[44px]", lg: "px-6 py-3 text-base min-h-[52px] w-full" };
  const variants = {
    primary: "bg-primary text-primary-foreground hover:opacity-90 shadow-sm",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border",
    ghost: "text-muted-foreground hover:text-foreground hover:bg-secondary",
    destructive: "bg-destructive text-destructive-foreground hover:opacity-90 shadow-sm",
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled || loading} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...rest}>
      {loading && <Loader2 size={16} className="animate-spin shrink-0" />}
      {children}
    </button>
  );
}

// Form Field
function Field({ label, error, hint, required, children }: {
  label: string; error?: string; hint?: string; required?: boolean; children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-sm font-semibold text-foreground">
        {label}{required && <span className="text-destructive ml-1" aria-hidden>*</span>}
      </label>
      {children}
      {hint && !error && <p className="text-xs text-muted-foreground">{hint}</p>}
      {error && (
        <p role="alert" className="text-xs text-destructive flex items-center gap-1">
          <TriangleAlert size={12} className="shrink-0" />{error}
        </p>
      )}
    </div>
  );
}

function Input({ className = "", ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={`w-full rounded-lg px-3.5 py-2.5 bg-input-background border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all min-h-[44px] ${className}`}
      {...props}
    />
  );
}

function MonoInput({ className = "", ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={`w-full rounded-lg px-3.5 py-2.5 bg-input-background border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all min-h-[44px] font-mono text-sm ${className}`}
      style={{ fontFamily: "'JetBrains Mono', monospace" }}
      {...props}
    />
  );
}

function Textarea({ className = "", ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={`w-full rounded-lg px-3.5 py-2.5 bg-input-background border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all resize-none ${className}`}
      {...props}
    />
  );
}

function Select({ className = "", ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={`w-full rounded-lg px-3.5 py-2.5 bg-input-background border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all min-h-[44px] cursor-pointer ${className}`}
      {...props}
    />
  );
}

function AlertBox({ type, children }: { type: "error" | "warning" | "info" | "success"; children: React.ReactNode }) {
  const styles = {
    error: "bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-800 dark:text-red-300",
    warning: "bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-900/20 dark:border-amber-800 dark:text-amber-300",
    info: "bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300",
    success: "bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-300",
  };
  const icons = { error: <XCircle size={16} />, warning: <TriangleAlert size={16} />, info: <Info size={16} />, success: <CheckCircle2 size={16} /> };
  return (
    <div role="alert" className={`flex gap-2.5 p-3.5 rounded-lg border text-sm ${styles[type]}`}>
      <span className="shrink-0 mt-0.5">{icons[type]}</span>
      <span>{children}</span>
    </div>
  );
}

// Progress steps indicator for multi-step flows
function ProgressSteps({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="flex items-center gap-0 w-full" role="progressbar" aria-valuenow={current} aria-valuemin={1} aria-valuemax={steps.length}>
      {steps.map((label, i) => {
        const num = i + 1;
        const done = num < current;
        const active = num === current;
        return (
          <div key={label} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-1 shrink-0">
              <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                done ? "bg-primary text-primary-foreground" :
                active ? "bg-primary text-primary-foreground ring-4 ring-primary/20" :
                "bg-secondary text-muted-foreground"
              }`}>
                {done ? <CheckCheck size={14} /> : num}
              </div>
              <span className={`text-[10px] font-semibold whitespace-nowrap hidden sm:block ${active ? "text-primary" : done ? "text-foreground" : "text-muted-foreground"}`}>
                {label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div className={`h-0.5 flex-1 mx-2 rounded transition-all ${done ? "bg-primary" : "bg-border"}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Layouts ──────────────────────────────────────────────────────────────────

function AuthShell({ children, theme, onThemeToggle }: {
  children: React.ReactNode; theme: Theme; onThemeToggle: () => void;
}) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
        <MediRouteLogo />
        <ThemeToggle theme={theme} onToggle={onThemeToggle} />
      </div>
      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 sm:py-12">
        {children}
      </div>
      {/* Footer */}
      <p className="text-center text-xs text-muted-foreground px-4 pb-6 max-w-sm mx-auto">
        By creating an account, you confirm this facility is a registered Nigerian healthcare provider. All accounts are subject to FMOH verification.
      </p>
    </div>
  );
}

function AppShell({ children, theme, onThemeToggle, title, onBack, onLogout }: {
  children: React.ReactNode; theme: Theme; onThemeToggle: () => void;
  title?: string; onBack?: () => void; onLogout: () => void;
}) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-30 bg-card border-b border-border shadow-sm">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          {onBack ? (
            <button type="button" onClick={onBack} aria-label="Go back"
              className="p-2 -ml-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary min-w-[44px] min-h-[44px] flex items-center justify-center transition-all">
              <ArrowLeft size={20} />
            </button>
          ) : (
            <MediRouteLogo />
          )}
          {title && <h1 className="text-base font-bold text-foreground flex-1 truncate">{title}</h1>}
          <div className="flex items-center gap-1 ml-auto">
            <ThemeToggle theme={theme} onToggle={onThemeToggle} />
            <button type="button" onClick={onLogout} aria-label="Sign out"
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary min-w-[44px] min-h-[44px] flex items-center justify-center transition-all">
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-6">
        {children}
      </main>
    </div>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-card border border-border rounded-xl shadow-sm ${className}`}>{children}</div>;
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3 mt-5 first:mt-0">
      {children}
    </p>
  );
}

// ─── Screen: Login ────────────────────────────────────────────────────────────
function LoginScreen({ onLogin, onForgotPassword, onCreateAccount, theme, onThemeToggle }: {
  onLogin: (username: string) => void; onForgotPassword: () => void; onCreateAccount: () => void;
  theme: Theme; onThemeToggle: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [authError, setAuthError] = useState("");

  function validate() {
    const e: Record<string, string> = {};
    if (!username.trim()) e.username = "Please enter your username or Facility ID";
    if (!password) e.password = "Please enter your password";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setAuthError("");
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    if (username === "wrong") {
      setAuthError("Incorrect username or password. Please check your details and try again.");
      return;
    }
    toast.success("Welcome back! You are now signed in.");
    onLogin(username);
  }

  return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-foreground mb-1.5">Sign in to MediRoute NG</h1>
          <p className="text-muted-foreground text-sm">Enter your credentials to access the referral platform</p>
        </div>

        <Card className="p-6">
          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
            {authError && <AlertBox type="error">{authError}</AlertBox>}

            <Field label="Username or Facility ID" required error={errors.username}
              hint="Use your HMIS username or Facility ID (e.g. awgu-phc-001)">
              <MonoInput
                type="text" placeholder="e.g. awgu-phc-001"
                value={username} onChange={e => { setUsername(e.target.value); setErrors(p => ({ ...p, username: "" })); }}
                autoComplete="username" aria-describedby="username-hint"
                aria-invalid={!!errors.username}
              />
            </Field>

            <Field label="Password" required error={errors.password}>
              <div className="relative">
                <Input
                  type={showPw ? "text" : "password"} placeholder="Enter your password"
                  value={password} onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: "" })); }}
                  autoComplete="current-password" className="pr-12"
                  aria-invalid={!!errors.password}
                />
                <button type="button" onClick={() => setShowPw(v => !v)}
                  aria-label={showPw ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-muted-foreground hover:text-foreground rounded transition-colors min-w-[36px] min-h-[36px] flex items-center justify-center">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </Field>

            <div className="flex justify-end -mt-2">
              <button type="button" onClick={onForgotPassword}
                className="text-sm text-primary hover:underline font-medium min-h-[44px] px-1 flex items-center">
                Forgot password?
              </button>
            </div>

            <Btn type="submit" size="lg" loading={loading}>
              {loading ? "Signing in…" : "Sign In"}
            </Btn>
          </form>
        </Card>

        {/* Divider */}
        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground font-medium">or</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        {/* Emergency button */}
        <button type="button"
          className="w-full flex items-center justify-center gap-2.5 p-3.5 rounded-xl border border-border bg-card text-foreground hover:bg-secondary transition-all min-h-[52px] font-semibold text-sm">
          <Siren size={18} className="text-destructive shrink-0" />
          <span>I need a hospital now — View public status</span>
        </button>
        <p className="text-xs text-muted-foreground text-center mt-2">No login required for the public hospital status board</p>

        <p className="text-sm text-muted-foreground text-center mt-5">
          New facility?{" "}
          <button type="button" onClick={onCreateAccount}
            className="text-primary font-semibold hover:underline min-h-[44px] inline-flex items-center">
            Register your facility
          </button>
        </p>
      </div>
    </AuthShell>
  );
}

// ─── Screen: Action Select (post-login hub) ───────────────────────────────────
function ActionSelectScreen({ onRefer, onManage, onCreateAccount, onLogout, theme, onThemeToggle, draftExists }: {
  onRefer: () => void; onManage: () => void; onCreateAccount: () => void;
  onLogout: () => void; theme: Theme; onThemeToggle: () => void; draftExists: boolean;
}) {
  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} onLogout={onLogout}>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Good morning 👋</h1>
          <p className="text-muted-foreground mt-1 text-sm">What would you like to do today?</p>
        </div>

        {draftExists && (
          <AlertBox type="info">
            You have an unsaved referral draft. Continue from where you left off.
          </AlertBox>
        )}

        {/* Main workflows */}
        <div className="flex flex-col gap-3">
          <button type="button" onClick={onRefer}
            className="w-full text-left bg-card border border-border rounded-xl p-5 hover:border-primary hover:shadow-md transition-all group min-h-[80px]">
            <div className="flex items-start gap-4">
              <div className="size-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                <Send size={20} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-foreground">Refer a Patient</p>
                  <ChevronRight size={18} className="text-muted-foreground shrink-0" />
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">
                  Create a referral, find a suitable facility, request tele-consultation
                </p>
              </div>
            </div>
          </button>

          <button type="button" onClick={onManage}
            className="w-full text-left bg-card border border-border rounded-xl p-5 hover:border-primary hover:shadow-md transition-all group min-h-[80px]">
            <div className="flex items-start gap-4">
              <div className="size-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent/20 transition-colors">
                <ClipboardList size={20} className="text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="font-bold text-foreground">Manage Incoming Referrals</p>
                    {MOCK_REFERRALS.filter(r => r.status === "PENDING").length > 0 && (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-600 dark:text-amber-400 mt-0.5">
                        <Bell size={11} /> {MOCK_REFERRALS.filter(r => r.status === "PENDING").length} awaiting your response
                      </span>
                    )}
                  </div>
                  <ChevronRight size={18} className="text-muted-foreground shrink-0" />
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">
                  Review, accept, decline, and manage patients referred to your facility
                </p>
              </div>
            </div>
          </button>
        </div>

        {/* Emergency */}
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground font-medium">or</span>
            <div className="flex-1 h-px bg-border" />
          </div>
          <button type="button"
            className="w-full flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:bg-secondary transition-all min-h-[52px]">
            <Siren size={20} className="text-destructive shrink-0" />
            <div className="text-left">
              <p className="text-sm font-semibold text-foreground">Emergency? View public hospital status</p>
              <p className="text-xs text-muted-foreground">No login required — real-time bed availability</p>
            </div>
          </button>
        </div>

        <p className="text-xs text-muted-foreground text-center">
          New facility on our network?{" "}
          <button type="button" onClick={onCreateAccount} className="text-primary font-semibold hover:underline">
            Register here
          </button>
        </p>
      </div>
    </AppShell>
  );
}

// ─── Refer Patient: Step 1 — Patient Information ──────────────────────────────
// ─── Refer Patient: Step 1 — Patient Details ─────────────────────────────────
function Step1PatientInfo({ draft, onUpdate, onNext, onSaveDraft, onCancel }: {
  draft: ReferralDraft; onUpdate: (d: Partial<ReferralDraft>) => void;
  onNext: () => void; onSaveDraft: () => void; onCancel: () => void;
}) {
  const [errors, setErrors] = useState<Record<string, string>>({});

  function validate() {
    const e: Record<string, string> = {};
    if (!draft.surname.trim()) e.surname = "Patient's surname is required";
    if (!draft.givenNames.trim()) e.givenNames = "Given name(s) are required";
    if (!draft.dob) e.dob = "Date of birth is required";
    else if (new Date(draft.dob) > new Date()) e.dob = "Date of birth cannot be in the future";
    if (!draft.sex) e.sex = "Please select the patient's sex";
    if (!draft.phone.trim()) e.phone = "A contact phone number is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function upd(k: keyof ReferralDraft) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      onUpdate({ [k]: e.target.value } as Partial<ReferralDraft>);
      setErrors(p => ({ ...p, [k]: "" }));
    };
  }

  return (
    <div className="flex flex-col gap-4">
      <AlertBox type="info">
        Fields marked <strong>*</strong> are required. Use the patient's legal name as it appears on their ID card or birth certificate.
      </AlertBox>

      {/* ── Identity ── */}
      <Card className="p-5">
        <SectionLabel>Patient Identity</SectionLabel>
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Surname" required error={errors.surname}
              hint="Family name / last name">
              <Input placeholder="e.g. Adeyemi" value={draft.surname} onChange={upd("surname")}
                aria-invalid={!!errors.surname} autoComplete="off" />
            </Field>
            <Field label="Other Names" required error={errors.givenNames}
              hint="First name, middle name">
              <Input placeholder="e.g. Chukwuemeka Emeka" value={draft.givenNames}
                onChange={upd("givenNames")} aria-invalid={!!errors.givenNames} autoComplete="off" />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Date of Birth" required error={errors.dob}>
              <Input type="date" value={draft.dob} max={new Date().toISOString().split("T")[0]}
                onChange={upd("dob")} aria-invalid={!!errors.dob} />
            </Field>
            <Field label="Sex" required error={errors.sex}>
              <Select value={draft.sex} onChange={upd("sex")} aria-invalid={!!errors.sex}>
                <option value="">Select sex…</option>
                <option value="M">Male</option>
                <option value="F">Female</option>
                <option value="O">Prefer not to say</option>
              </Select>
            </Field>
          </div>

          <Field label="Residential Address"
            hint="Street, town/LGA — helps with ambulance routing">
            <Input placeholder="e.g. 14 Bode Thomas St, Surulere, Lagos"
              value={draft.address} onChange={upd("address")} />
          </Field>

          <Field label="Patient's Phone Number" required error={errors.phone}
            hint="Patient's own number or a relative who is with the patient now">
            <Input type="tel" placeholder="+234 800 000 0000" value={draft.phone}
              onChange={upd("phone")} autoComplete="tel" aria-invalid={!!errors.phone} />
          </Field>
        </div>
      </Card>

      {/* ── ID / Insurance ── */}
      <Card className="p-5">
        <SectionLabel>Identification &amp; Insurance</SectionLabel>
        <p className="text-xs text-muted-foreground mb-4">Optional but speeds up admission at the receiving facility.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="NIN" hint="11-digit National Identification Number">
            <MonoInput placeholder="12345678901" value={draft.nin}
              onChange={upd("nin")} maxLength={11} />
          </Field>
          <Field label="NHIS / HMO Number" hint="National Health Insurance or private HMO number">
            <MonoInput placeholder="NHIS-XXXXXXXX" value={draft.nhis}
              onChange={upd("nhis")} />
          </Field>
        </div>
      </Card>

      {/* ── Medical background ── */}
      <Card className="p-5">
        <SectionLabel>Medical Background</SectionLabel>
        <div className="flex flex-col gap-4">
          <Field label="Known Allergies"
            hint="Drug allergies, food allergies, latex — write NKDA if none known">
            <Textarea placeholder="e.g. Penicillin (rash), NKDA, sulfa drugs…"
              value={draft.allergies} rows={2} onChange={upd("allergies")} />
          </Field>
          <Field label="Current Medications"
            hint="List all drugs the patient is currently taking, with doses if known">
            <Textarea
              placeholder="e.g. Amlodipine 5mg OD, Metformin 500mg BD, Aspirin 75mg OD…"
              value={draft.currentMedications} rows={3} onChange={upd("currentMedications")} />
          </Field>
        </div>
      </Card>

      {/* ── Next of kin ── */}
      <Card className="p-5">
        <SectionLabel>Next of Kin</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Full Name">
            <Input placeholder="Full name of next of kin" value={draft.nokName}
              onChange={upd("nokName")} autoComplete="off" />
          </Field>
          <Field label="Relationship to Patient">
            <Select value={draft.nokRelationship} onChange={upd("nokRelationship")}>
              <option value="">Select relationship…</option>
              {["Spouse", "Parent", "Child", "Sibling", "Aunt / Uncle", "Cousin", "Friend", "Guardian", "Other"].map(r =>
                <option key={r} value={r}>{r}</option>)}
            </Select>
          </Field>
          <Field label="Phone Number">
            <Input type="tel" placeholder="+234 800 000 0000" value={draft.nokPhone}
              onChange={upd("nokPhone")} />
          </Field>
        </div>
      </Card>

      <div className="flex gap-4">
        <Btn variant="ghost" onClick={onCancel} size="md">
          <X size={16} /> Cancel
        </Btn>
        <Btn variant="secondary" onClick={onSaveDraft} size="md">
          <Save size={16} /> Save Draft
        </Btn>
        <Btn onClick={() => { if (validate()) onNext(); }} size="md" className="flex-1">
          Next — Clinical Details <ChevronRight size={16} />
        </Btn>
      </div>
    </div>
  );
}

// ─── Refer Patient: Step 2 — Clinical Details ─────────────────────────────────
function Step2ClinicalDetails({ draft, onUpdate, onNext, onBack, onSaveDraft }: {
  draft: ReferralDraft; onUpdate: (d: Partial<ReferralDraft>) => void;
  onNext: () => void; onBack: () => void; onSaveDraft: () => void;
}) {
  const [errors, setErrors] = useState<Record<string, string>>({});

  function validate() {
    const e: Record<string, string> = {};
    if (!draft.urgency) e.urgency = "Please select the urgency level — this determines how quickly the facility is alerted";
    if (!draft.reasonForReferral.trim()) e.reasonForReferral = "Reason for referral is required";
    if (!draft.chiefComplaint.trim()) e.chiefComplaint = "Chief complaint is required";
    if (!draft.clinicianName.trim()) e.clinicianName = "Referring clinician's name is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function upd(k: keyof ReferralDraft) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      onUpdate({ [k]: e.target.value } as Partial<ReferralDraft>);
      setErrors(p => ({ ...p, [k]: "" }));
    };
  }

  return (
    <div className="flex flex-col gap-4">

      {/* ── Urgency ── */}
      <Card className="p-5">
        <SectionLabel>Urgency Level *</SectionLabel>
        {errors.urgency && <div className="mb-4"><AlertBox type="error">{errors.urgency}</AlertBox></div>}
        <div className="flex flex-col gap-3">
          {(["IMMEDIATE", "URGENT", "ROUTINE"] as UrgencyLevel[]).map(level => {
            const cfg = URGENCY_CONFIG[level];
            const selected = draft.urgency === level;
            return (
              <label key={level}
                className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  selected ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40 hover:bg-secondary/30"
                }`}>
                <input type="radio" name="urgency" value={level} checked={selected}
                  onChange={() => { onUpdate({ urgency: level }); setErrors(p => ({ ...p, urgency: "" })); }}
                  className="sr-only" />
                <div className={`size-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-1 transition-all ${
                  selected ? "border-primary" : "border-muted-foreground"
                }`}>
                  {selected && <div className="size-3 rounded-full bg-primary" />}
                </div>
                <div className="flex-1">
                  <div className="mb-1"><UrgencyBadge level={level} /></div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{cfg.sublabel}</p>
                </div>
              </label>
            );
          })}
        </div>
        {draft.urgency === "IMMEDIATE" && (
          <div className="mt-4">
            <AlertBox type="error">
              <strong>Immediate urgency:</strong> Also call the receiving facility right now. Do not rely on this system alone for life-threatening emergencies.
            </AlertBox>
          </div>
        )}
      </Card>

      {/* ── Reason for referral ── */}
      <Card className="p-5">
        <SectionLabel>Reason for Referral</SectionLabel>
        <div className="flex flex-col gap-4">
          <Field label="Why are you referring this patient?" required error={errors.reasonForReferral}
            hint="What specific service, investigation, or specialist opinion do you need?">
            <Textarea
              placeholder="e.g. Needs specialist cardiology review and possible PCI. Echocardiogram and troponin results not available at this facility."
              value={draft.reasonForReferral} rows={3} onChange={upd("reasonForReferral")}
              aria-invalid={!!errors.reasonForReferral} />
          </Field>
          <Field label="Specialty Requested"
            hint="Which specialty department should receive this patient?">
            <Select value={draft.specialtyNeeded} onChange={upd("specialtyNeeded")}>
              <option value="">Select specialty…</option>
              {["Emergency Medicine", "Cardiology", "Neurology / Neurosurgery",
                "Obstetrics & Gynaecology", "Paediatrics / Neonatology",
                "Orthopaedics & Trauma", "General Surgery", "Internal Medicine",
                "Nephrology", "Oncology", "Ophthalmology", "ENT",
                "Psychiatry / Mental Health", "Dermatology", "Urology",
                "Haematology", "Endocrinology", "Pulmonology", "ICU / Critical Care",
                "Burns & Plastic Surgery", "Other"].map(s =>
                <option key={s} value={s}>{s}</option>)}
            </Select>
          </Field>
        </div>
      </Card>

      {/* ── Clinical presentation ── */}
      <Card className="p-5">
        <SectionLabel>Clinical Presentation</SectionLabel>
        <div className="flex flex-col gap-4">
          <Field label="Chief Complaint" required error={errors.chiefComplaint}
            hint="The patient's main symptom in their own words or as reported">
            <Textarea
              placeholder="e.g. Severe chest pain radiating to left arm and jaw, started 2 hours ago, associated with sweating and breathlessness"
              value={draft.chiefComplaint} rows={3} onChange={upd("chiefComplaint")}
              aria-invalid={!!errors.chiefComplaint} />
          </Field>

          <Field label="Duration of Illness"
            hint="How long has the patient had this complaint?">
            <Input placeholder="e.g. 3 hours / 2 days / 1 week" value={draft.duration}
              onChange={upd("duration")} />
          </Field>

          <Field label="History of Presenting Illness"
            hint="Detailed account — onset, progression, associated symptoms, relieving / aggravating factors">
            <Textarea
              placeholder="e.g. Patient was resting when sudden onset severe central chest pain developed, radiating to left arm. Associated with diaphoresis, nausea, and one episode of vomiting. No previous episodes. Known hypertensive for 5 years, poorly controlled. Currently on amlodipine 5mg OD."
              value={draft.historyOfPresentingIllness} rows={5}
              onChange={upd("historyOfPresentingIllness")} />
          </Field>

          <Field label="Provisional Diagnosis"
            hint="Your working diagnosis — does not need to be definitive">
            <Input
              placeholder="e.g. Suspected STEMI / Pre-eclampsia with severe features / Closed femur fracture"
              value={draft.provisionalDiagnosis} onChange={upd("provisionalDiagnosis")} />
          </Field>
        </div>
      </Card>

      {/* ── Examination & investigations ── */}
      <Card className="p-5">
        <SectionLabel>Examination Findings &amp; Investigations</SectionLabel>
        <div className="flex flex-col gap-4">
          <Field label="Physical Examination Findings"
            hint="Relevant positive and negative findings on examination">
            <Textarea
              placeholder="e.g. Alert, distressed, diaphoretic. CVS: irregular pulse, S3 gallop heard. RS: bibasal crackles. Abdomen: soft, non-tender."
              value={draft.examinationFindings} rows={4}
              onChange={upd("examinationFindings")} />
          </Field>
          <Field label="Investigations Done &amp; Results"
            hint="Lab results, X-rays, ECG findings, ultrasound — include values and dates">
            <Textarea
              placeholder="e.g. ECG (today): ST elevation leads II, III, aVF. RBS: 6.2 mmol/L. PCV: 28%. Urine dipstick: protein ++. X-ray: not done."
              value={draft.investigations} rows={4}
              onChange={upd("investigations")} />
          </Field>
        </div>
      </Card>

      {/* ── Vital signs ── */}
      <Card className="p-5">
        <SectionLabel>Vital Signs at Time of Referral</SectionLabel>
        <p className="text-xs text-muted-foreground mb-4">Record the most recent set of observations.</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { key: "bp",     label: "Blood Pressure",      placeholder: "120/80 mmHg" },
            { key: "pulse",  label: "Pulse Rate",           placeholder: "88 bpm" },
            { key: "temp",   label: "Temperature",          placeholder: "37.2 °C" },
            { key: "rr",     label: "Respiratory Rate",     placeholder: "18 /min" },
            { key: "spo2",   label: "SpO₂",                 placeholder: "97 %" },
            { key: "weight", label: "Weight",               placeholder: "68 kg" },
            { key: "height", label: "Height",               placeholder: "165 cm" },
            { key: "muac",   label: "MUAC",                 placeholder: "e.g. 22 cm (paeds)" },
          ].map(({ key, label, placeholder }) => (
            <Field key={key} label={label}>
              <MonoInput placeholder={placeholder}
                value={draft[key as keyof ReferralDraft] as string}
                onChange={upd(key as keyof ReferralDraft)} />
            </Field>
          ))}
        </div>
      </Card>

      {/* ── Treatment given ── */}
      <Card className="p-5">
        <SectionLabel>Treatment Already Given</SectionLabel>
        <Field label="Medicines &amp; interventions administered before referral"
          hint="Include drug name, dose, route, and time given">
          <Textarea
            placeholder="e.g. IV access secured (R antecubital). Aspirin 300mg PO given 13:20. GTN spray ×2. O₂ via face mask 6L/min. IV fluids: 0.9% NaCl 500mL started."
            value={draft.treatmentGiven} rows={4}
            onChange={upd("treatmentGiven")} />
        </Field>
      </Card>

      {/* ── Referring clinician ── */}
      <Card className="p-5">
        <SectionLabel>Referring Clinician Details</SectionLabel>
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Clinician's Full Name" required error={errors.clinicianName}>
              <Input placeholder="e.g. Dr. Ngozi Okonkwo" value={draft.clinicianName}
                onChange={upd("clinicianName")} aria-invalid={!!errors.clinicianName} />
            </Field>
            <Field label="MDCN / NMCN Reg. Number"
              hint="Medical or Nursing council registration number">
              <MonoInput placeholder="e.g. MDCN/2019/12345" value={draft.clinicianMdcn}
                onChange={upd("clinicianMdcn")} />
            </Field>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Department / Ward / Unit">
              <Input placeholder="e.g. A&E / Maternity / Medical Ward 3"
                value={draft.department} onChange={upd("department")} />
            </Field>
            <Field label="Date of Referral">
              <Input type="date" value={draft.referralDate} onChange={upd("referralDate")} />
            </Field>
          </div>
        </div>
      </Card>

      <div className="flex gap-4">
        <Btn variant="ghost" onClick={onBack} size="md">
          <ArrowLeft size={16} /> Back
        </Btn>
        <Btn variant="secondary" onClick={onSaveDraft} size="md">
          <Save size={16} /> Draft
        </Btn>
        <Btn onClick={() => { if (validate()) onNext(); }} size="md" className="flex-1">
          Next — Select Facility <ChevronRight size={16} />
        </Btn>
      </div>
    </div>
  );
}

// ─── Refer Patient: Step 3 — Select Receiving Facility ────────────────────────
function Step3SelectFacility({ draft, onUpdate, onNext, onBack }: {
  draft: ReferralDraft; onUpdate: (d: Partial<ReferralDraft>) => void;
  onNext: () => void; onBack: () => void;
}) {
  const [query, setQuery] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = MOCK_FACILITIES.filter(f => {
    const q = query.toLowerCase();
    const matchesQuery = !q || f.name.toLowerCase().includes(q) ||
      f.specialties.some(s => s.toLowerCase().includes(q)) ||
      f.type.toLowerCase().includes(q) || f.state.toLowerCase().includes(q);
    const matchesSpecialty = !draft.specialtyNeeded ||
      f.specialties.some(s => s.toLowerCase().includes(draft.specialtyNeeded.toLowerCase())) ||
      f.specialties.some(s => s.includes("All Specialties"));
    return matchesQuery && matchesSpecialty;
  });

  function validate() {
    const e: Record<string, string> = {};
    if (!draft.selectedFacilityId) e.facility = "Please select a receiving facility before continuing";
    if (!draft.transportMode) e.transport = "Please select how the patient will be transported";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  return (
    <div className="flex flex-col gap-4">
      {draft.urgency === "IMMEDIATE" && (
        <AlertBox type="error">
          <strong>Immediate urgency.</strong> Call the receiving facility by phone right now before submitting this form.
        </AlertBox>
      )}

      {/* ── Facility search ── */}
      <Card className="p-5">
        <SectionLabel>Find a Receiving Facility</SectionLabel>
        {errors.facility && <div className="mb-4"><AlertBox type="error">{errors.facility}</AlertBox></div>}
        {draft.specialtyNeeded && (
          <div className="mb-4 flex items-center gap-2 p-3 bg-primary/5 rounded-lg border border-primary/20">
            <Stethoscope size={14} className="text-primary shrink-0" />
            <p className="text-xs text-primary font-semibold">
              Filtering for: <span className="font-bold">{draft.specialtyNeeded}</span>
            </p>
            <button type="button" onClick={() => onUpdate({ specialtyNeeded: "" })}
              className="ml-auto text-muted-foreground hover:text-foreground transition-colors">
              <X size={14} />
            </button>
          </div>
        )}
        <div className="relative">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-10" placeholder="Search by facility name, specialty, or state…"
            value={query} onChange={e => setQuery(e.target.value)} />
        </div>
      </Card>

      <div className="flex flex-col gap-3">
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Building2 size={36} className="mx-auto mb-3 opacity-30" />
            <p className="font-semibold text-sm">No facilities match your search</p>
            <p className="text-xs mt-1">Try a broader search term or clear the specialty filter</p>
          </div>
        )}
        {filtered.map(facility => {
          const selected = draft.selectedFacilityId === facility.id;
          const bedCfg = BED_CONFIG[facility.beds];
          return (
            <button key={facility.id} type="button"
              onClick={() => { onUpdate({ selectedFacilityId: facility.id }); setErrors(p => ({ ...p, facility: "" })); }}
              className={`w-full text-left rounded-xl border-2 p-4 transition-all ${
                selected ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40 hover:bg-secondary/30"
              }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <p className="font-bold text-foreground">{facility.name}</p>
                    {selected && <CheckCircle2 size={16} className="text-primary shrink-0" />}
                  </div>
                  <p className="text-xs text-muted-foreground">{facility.type}</p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin size={11} />{facility.state} · {facility.distance}
                    </span>
                    <span className="text-muted-foreground">·</span>
                    <span className={`text-xs font-semibold ${bedCfg.cls}`}>{bedCfg.label}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                    <Phone size={11} />{facility.phone}
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {facility.specialties.slice(0, 4).map(s => (
                      <span key={s}
                        className={`text-[11px] px-2 py-1 rounded-full ${
                          draft.specialtyNeeded && s.toLowerCase().includes(draft.specialtyNeeded.toLowerCase())
                            ? "bg-primary/15 text-primary font-semibold"
                            : "bg-secondary text-secondary-foreground"
                        }`}>{s}</span>
                    ))}
                    {facility.specialties.length > 4 && (
                      <span className="text-[11px] text-muted-foreground py-1">+{facility.specialties.length - 4} more</span>
                    )}
                  </div>
                </div>
                <div className={`size-6 rounded-full border-2 flex items-center justify-center shrink-0 mt-1 transition-all ${
                  selected ? "border-primary bg-primary" : "border-muted-foreground"
                }`}>
                  {selected && <div className="size-2 rounded-full bg-white" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* ── Transport & Escort ── */}
      <Card className="p-5">
        <SectionLabel>Transport Arrangement *</SectionLabel>
        {errors.transport && <div className="mb-4"><AlertBox type="error">{errors.transport}</AlertBox></div>}
        <div className="flex flex-col gap-3">
          {[
            { value: "AMBULANCE", label: "Ambulance", sub: "Government or private ambulance with medical equipment" },
            { value: "PRIVATE",   label: "Private Vehicle", sub: "Family car, taxi, or other private transport" },
            { value: "WALK_IN",   label: "Patient Walking / Own Means", sub: "Patient is stable and able to travel independently" },
          ].map(opt => {
            const sel = draft.transportMode === opt.value;
            return (
              <label key={opt.value}
                className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  sel ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40 hover:bg-secondary/30"
                }`}>
                <input type="radio" name="transport" value={opt.value} checked={sel}
                  onChange={() => { onUpdate({ transportMode: opt.value }); setErrors(p => ({ ...p, transport: "" })); }}
                  className="sr-only" />
                <div className={`size-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-1 ${
                  sel ? "border-primary" : "border-muted-foreground"
                }`}>
                  {sel && <div className="size-3 rounded-full bg-primary" />}
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{opt.label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{opt.sub}</p>
                </div>
              </label>
            );
          })}
        </div>

        <div className="mt-4">
          <Field label="Clinical Escort Required"
            hint="Will a healthcare worker accompany the patient?">
            <Select value={draft.escortRequired} onChange={e => onUpdate({ escortRequired: e.target.value })}>
              <option value="">Select escort type…</option>
              <option value="NONE">No escort — patient can travel alone</option>
              <option value="RELATIVE">Relative / guardian escort only</option>
              <option value="NURSE">Nurse escort required</option>
              <option value="DOCTOR">Doctor escort required (critical patient)</option>
            </Select>
          </Field>
        </div>
      </Card>

      <div className="flex gap-4">
        <Btn variant="ghost" onClick={onBack} size="md">
          <ArrowLeft size={16} /> Back
        </Btn>
        <Btn onClick={() => { if (validate()) onNext(); }} size="md" className="flex-1">
          Review Referral <ChevronRight size={16} />
        </Btn>
      </div>
    </div>
  );
}

// ─── Refer Patient: Step 4 — Review & Submit ──────────────────────────────────
function ReviewRow({ label, value }: { label: string; value: string }) {
  if (!value) return null;
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-medium text-foreground mt-1">{value}</p>
    </div>
  );
}

function ReviewSection({ title, onEdit, children }: {
  title: string; onEdit: () => void; children: React.ReactNode;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between mb-4">
        <SectionLabel>{title}</SectionLabel>
        <button type="button" onClick={onEdit}
          className="text-xs text-primary font-semibold flex items-center gap-1 hover:underline min-h-[36px] px-1">
          <Edit2 size={12} /> Edit
        </button>
      </div>
      <div className="flex flex-col gap-3">{children}</div>
    </Card>
  );
}

function Step4ReviewSubmit({ draft, onBack, onSubmit, onEditStep }: {
  draft: ReferralDraft; onBack: () => void; onSubmit: () => void; onEditStep: (s: 1 | 2 | 3) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [notes, setNotes] = useState(draft.referralNotes);
  const facility = MOCK_FACILITIES.find(f => f.id === draft.selectedFacilityId);

  async function handleSubmit() {
    setLoading(true);
    await new Promise(r => setTimeout(r, 2000));
    setLoading(false);
    onSubmit();
  }

  const patientAge = draft.dob
    ? `${Math.floor((Date.now() - new Date(draft.dob).getTime()) / (365.25 * 24 * 3600 * 1000))} years`
    : "—";

  const sexLabel = draft.sex === "M" ? "Male" : draft.sex === "F" ? "Female" : draft.sex || "—";
  const transportLabel: Record<string, string> = {
    AMBULANCE: "Ambulance", PRIVATE: "Private Vehicle", WALK_IN: "Patient Walking / Own Means",
  };
  const escortLabel: Record<string, string> = {
    NONE: "No escort", RELATIVE: "Relative / guardian", NURSE: "Nurse escort", DOCTOR: "Doctor escort",
  };

  const vitalsFormatted = [
    draft.bp && `BP: ${draft.bp}`, draft.pulse && `Pulse: ${draft.pulse}`,
    draft.temp && `Temp: ${draft.temp}`, draft.rr && `RR: ${draft.rr}`,
    draft.spo2 && `SpO₂: ${draft.spo2}`, draft.weight && `Wt: ${draft.weight}`,
    draft.height && `Ht: ${draft.height}`, draft.muac && `MUAC: ${draft.muac}`,
  ].filter(Boolean).join("   ·   ");

  return (
    <div className="flex flex-col gap-4">
      <AlertBox type="warning">
        Review every section carefully. Once submitted, the receiving facility is notified immediately and this referral cannot be recalled.
      </AlertBox>

      {/* Urgency banner */}
      {draft.urgency && (
        <div className="flex items-center gap-3 p-4 rounded-xl border-2 border-border bg-card">
          <UrgencyBadge level={draft.urgency as UrgencyLevel} />
          <p className="text-xs text-muted-foreground">{URGENCY_CONFIG[draft.urgency as UrgencyLevel].sublabel}</p>
        </div>
      )}

      {/* Patient */}
      <ReviewSection title="Patient Details" onEdit={() => onEditStep(1)}>
        <div className="grid grid-cols-2 gap-x-4 gap-y-3">
          <ReviewRow label="Full Name" value={`${draft.surname}, ${draft.givenNames}`} />
          <ReviewRow label="Date of Birth" value={draft.dob} />
          <ReviewRow label="Age" value={patientAge} />
          <ReviewRow label="Sex" value={sexLabel} />
          <ReviewRow label="Phone" value={draft.phone} />
          <ReviewRow label="Address" value={draft.address} />
          <ReviewRow label="NIN" value={draft.nin || "Not provided"} />
          <ReviewRow label="NHIS / HMO" value={draft.nhis || "Not provided"} />
        </div>
        {draft.nokName && (
          <div className="pt-3 border-t border-border">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Next of Kin</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
              <ReviewRow label="Name" value={draft.nokName} />
              <ReviewRow label="Relationship" value={draft.nokRelationship} />
              <ReviewRow label="Phone" value={draft.nokPhone} />
            </div>
          </div>
        )}
        {(draft.allergies || draft.currentMedications) && (
          <div className="pt-3 border-t border-border">
            <ReviewRow label="Known Allergies" value={draft.allergies || "NKDA / Not recorded"} />
            <div className="mt-3">
              <ReviewRow label="Current Medications" value={draft.currentMedications || "None recorded"} />
            </div>
          </div>
        )}
      </ReviewSection>

      {/* Clinical */}
      <ReviewSection title="Clinical Details" onEdit={() => onEditStep(2)}>
        <ReviewRow label="Reason for Referral" value={draft.reasonForReferral} />
        <ReviewRow label="Specialty Requested" value={draft.specialtyNeeded} />
        <ReviewRow label="Chief Complaint" value={draft.chiefComplaint} />
        <ReviewRow label="Duration" value={draft.duration} />
        <ReviewRow label="History of Presenting Illness" value={draft.historyOfPresentingIllness} />
        <ReviewRow label="Provisional Diagnosis" value={draft.provisionalDiagnosis} />
        <ReviewRow label="Examination Findings" value={draft.examinationFindings} />
        <ReviewRow label="Investigations Done" value={draft.investigations} />
        {vitalsFormatted && (
          <div>
            <p className="text-xs text-muted-foreground mb-2">Vital Signs</p>
            <p className="text-xs font-mono bg-secondary px-3 py-2 rounded-lg text-foreground leading-relaxed"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              {vitalsFormatted}
            </p>
          </div>
        )}
        <ReviewRow label="Treatment Given Before Referral" value={draft.treatmentGiven} />
        <div className="pt-3 border-t border-border grid grid-cols-2 gap-x-4 gap-y-3">
          <ReviewRow label="Referring Clinician" value={draft.clinicianName} />
          <ReviewRow label="MDCN / NMCN Reg. No." value={draft.clinicianMdcn} />
          <ReviewRow label="Department / Ward" value={draft.department} />
          <ReviewRow label="Date of Referral" value={draft.referralDate} />
        </div>
      </ReviewSection>

      {/* Facility & transport */}
      <ReviewSection title="Receiving Facility &amp; Transport" onEdit={() => onEditStep(3)}>
        {facility ? (
          <>
            <div>
              <p className="font-bold text-foreground">{facility.name}</p>
              <p className="text-sm text-muted-foreground">{facility.type} · {facility.state}</p>
              <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                <Phone size={12} />{facility.phone}
              </p>
            </div>
            <ReviewRow label="Transport Mode" value={transportLabel[draft.transportMode] || draft.transportMode} />
            <ReviewRow label="Clinical Escort" value={escortLabel[draft.escortRequired] || draft.escortRequired} />
          </>
        ) : (
          <AlertBox type="error">No facility selected. Go back to Step 3.</AlertBox>
        )}
      </ReviewSection>

      {/* Additional notes */}
      <Card className="p-5">
        <SectionLabel>Additional Notes for Receiving Team</SectionLabel>
        <Field label="" hint="Anything else the receiving team should know before the patient arrives">
          <Textarea
            placeholder="e.g. Patient is anxious — please reassure on arrival. Husband will accompany. Patient speaks Yoruba primarily."
            value={notes} rows={3}
            onChange={e => setNotes(e.target.value)} />
        </Field>
      </Card>

      <div className="flex gap-4">
        <Btn variant="ghost" onClick={onBack} size="md">
          <ArrowLeft size={16} /> Back
        </Btn>
        <Btn onClick={handleSubmit} size="md" className="flex-1" loading={loading}
          disabled={!facility}>
          {loading ? "Sending Referral…" : <><Send size={16} /> Send Referral</>}
        </Btn>
      </div>
    </div>
  );
}

// ─── Refer Patient: Multi-step container ─────────────────────────────────────
function ReferPatientFlow({ initialStep = 1, onDone, onCancel, theme, onThemeToggle, onLogout }: {
  initialStep?: 1 | 2 | 3 | 4; onDone: (referralId: string) => void; onCancel: () => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void;
}) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(initialStep);
  const [draft, setDraft] = useState<ReferralDraft>(() => {
    try {
      const saved = localStorage.getItem("mediroute-draft");
      return saved ? { ...EMPTY_DRAFT, ...JSON.parse(saved) } : EMPTY_DRAFT;
    } catch { return EMPTY_DRAFT; }
  });

  function update(d: Partial<ReferralDraft>) { setDraft(p => ({ ...p, ...d })); }

  function saveDraft() {
    localStorage.setItem("mediroute-draft", JSON.stringify(draft));
    toast.success("Draft saved. You can return to it at any time.");
  }

  const STEPS = ["Patient Details", "Clinical Details", "Select Facility", "Review & Send"];

  function goBack() {
    if (step > 1) setStep(s => (s - 1) as 1 | 2 | 3 | 4);
    else onCancel();
  }

  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} title="New Patient Referral"
      onBack={goBack} onLogout={onLogout}>
      <div className="flex flex-col gap-6">
        <ProgressSteps steps={STEPS} current={step} />
        <div>
          <h2 className="text-lg font-bold text-foreground">{STEPS[step - 1]}</h2>
          <p className="text-sm text-muted-foreground mt-1">Step {step} of {STEPS.length}</p>
        </div>

        {step === 1 && (
          <Step1PatientInfo draft={draft} onUpdate={update}
            onNext={() => setStep(2)} onSaveDraft={saveDraft} onCancel={onCancel} />
        )}
        {step === 2 && (
          <Step2ClinicalDetails draft={draft} onUpdate={update}
            onNext={() => setStep(3)} onBack={() => setStep(1)} onSaveDraft={saveDraft} />
        )}
        {step === 3 && (
          <Step3SelectFacility draft={draft} onUpdate={update}
            onNext={() => setStep(4)} onBack={() => setStep(2)} />
        )}
        {step === 4 && (
          <Step4ReviewSubmit draft={draft} onBack={() => setStep(3)} onEditStep={s => setStep(s)}
            onSubmit={() => {
              localStorage.removeItem("mediroute-draft");
              onDone(`REF-${new Date().getFullYear()}-${Math.floor(Math.random() * 9000 + 1000)}`);
            }} />
        )}
      </div>
    </AppShell>
  );
}

// ─── Screen: Referral Submitted ───────────────────────────────────────────────
function ReferralSubmittedScreen({ referralId, onNewReferral, onManage, theme, onThemeToggle, onLogout }: {
  referralId: string; onNewReferral: () => void; onManage: () => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void;
}) {
  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} onLogout={onLogout}>
      <div className="flex flex-col items-center text-center py-8 gap-6">
        <div className="size-20 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
          <CheckCircle2 size={40} className="text-emerald-600 dark:text-emerald-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Referral Sent!</h1>
          <p className="text-muted-foreground mt-2 max-w-sm text-sm leading-relaxed">
            The receiving facility has been notified and will respond as soon as possible. Monitor the status below.
          </p>
        </div>

        <Card className="w-full text-left p-5">
          <p className="text-xs text-muted-foreground mb-1">Referral ID</p>
          <p className="font-bold font-mono text-lg text-foreground" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            {referralId}
          </p>
          <p className="text-xs text-muted-foreground mt-3">Keep this reference number. You can use it to track this referral at any time.</p>
        </Card>

        <AlertBox type="info">
          If this is an <strong>immediate urgency</strong> case, please also call the receiving facility directly to confirm receipt. Do not rely solely on this system alert.
        </AlertBox>

        <div className="flex flex-col gap-3 w-full">
          <Btn size="lg" onClick={onManage}>
            <ClipboardList size={18} /> Track This Referral
          </Btn>
          <Btn size="lg" variant="secondary" onClick={onNewReferral}>
            <Send size={18} /> Send Another Referral
          </Btn>
        </div>
      </div>
    </AppShell>
  );
}

// ─── Screen: Manage Referrals ─────────────────────────────────────────────────
type ReferralFilter = "ALL" | ReferralStatus;

function ManageReferralsScreen({ onViewDetail, onBack, theme, onThemeToggle, onLogout }: {
  onViewDetail: (id: string) => void; onBack: () => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void;
}) {
  const [filter, setFilter] = useState<ReferralFilter>("ALL");
  const [search, setSearch] = useState("");

  const filtered = MOCK_REFERRALS.filter(r =>
    (filter === "ALL" || r.status === filter) &&
    (!search || r.patient.name.toLowerCase().includes(search.toLowerCase()) ||
      r.chiefComplaint.toLowerCase().includes(search.toLowerCase()) ||
      r.referringFacility.toLowerCase().includes(search.toLowerCase()) ||
      r.id.toLowerCase().includes(search.toLowerCase()))
  );

  const tabs: { key: ReferralFilter; label: string }[] = [
    { key: "ALL", label: "All" },
    { key: "PENDING", label: "Pending" },
    { key: "ACCEPTED", label: "Accepted" },
    { key: "IN_TRANSIT", label: "En Route" },
    { key: "DECLINED", label: "Declined" },
    { key: "COMPLETED", label: "Completed" },
  ];

  const pendingCount = MOCK_REFERRALS.filter(r => r.status === "PENDING").length;

  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} title="Incoming Referrals"
      onBack={onBack} onLogout={onLogout}>
      <div className="flex flex-col gap-4">
        {pendingCount > 0 && (
          <AlertBox type="warning">
            <strong>{pendingCount} referral{pendingCount > 1 ? "s" : ""}</strong> awaiting your response. Please review and act promptly.
          </AlertBox>
        )}

        {/* Search */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-10" placeholder="Search by patient name, complaint, or Ref ID…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-4 px-4">
          {tabs.map(({ key, label }) => {
            const count = key === "ALL" ? MOCK_REFERRALS.length : MOCK_REFERRALS.filter(r => r.status === key).length;
            return (
              <button key={key} type="button" onClick={() => setFilter(key)}
                className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all min-h-[36px] ${
                  filter === key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}>
                {label}
                {count > 0 && (
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                    filter === key ? "bg-white/20 text-white" : "bg-border text-muted-foreground"
                  }`}>{count}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* List */}
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <ClipboardList size={40} className="mx-auto mb-3 opacity-30" />
            <p className="font-semibold">No referrals found</p>
            <p className="text-sm mt-1">Try a different filter or search term</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map(ref => (
              <button key={ref.id} type="button" onClick={() => onViewDetail(ref.id)}
                className="w-full text-left bg-card border border-border rounded-xl p-4 hover:border-primary/50 hover:shadow-sm transition-all">
                {/* Header row */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <UrgencyBadge level={ref.urgency} />
                    <StatusBadge status={ref.status} />
                  </div>
                  <p className="text-xs text-muted-foreground shrink-0">{ref.receivedAt}</p>
                </div>
                {/* Patient name + age */}
                <div className="flex items-center gap-2 mb-1">
                  <div className="size-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs shrink-0">
                    {ref.patient.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                  </div>
                  <div>
                    <p className="font-bold text-foreground text-sm">{ref.patient.name}</p>
                    <p className="text-xs text-muted-foreground">{ref.patient.age} yrs · {ref.patient.sex === "M" ? "Male" : "Female"}</p>
                  </div>
                </div>
                {/* Complaint */}
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{ref.chiefComplaint}</p>
                {/* Footer */}
                <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border">
                  <Building2 size={12} className="text-muted-foreground shrink-0" />
                  <p className="text-xs text-muted-foreground truncate">From: {ref.referringFacility}</p>
                  <ChevronRight size={14} className="text-muted-foreground ml-auto shrink-0" />
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

// ─── Screen: Referral Detail ──────────────────────────────────────────────────
function ReferralDetailScreen({ referralId, onBack, theme, onThemeToggle, onLogout }: {
  referralId: string; onBack: () => void; theme: Theme; onThemeToggle: () => void; onLogout: () => void;
}) {
  const ref = MOCK_REFERRALS.find(r => r.id === referralId);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [localStatus, setLocalStatus] = useState(ref?.status);

  if (!ref) return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} onBack={onBack} onLogout={onLogout}>
      <AlertBox type="error">Referral not found. It may have been removed.</AlertBox>
    </AppShell>
  );

  async function handleAction(action: string, newStatus: ReferralStatus) {
    setActionLoading(action);
    await new Promise(r => setTimeout(r, 1500));
    setLocalStatus(newStatus);
    setActionLoading(null);
    if (newStatus === "ACCEPTED") toast.success("Referral accepted. The referring facility has been notified.");
    if (newStatus === "DECLINED") toast.error("Referral declined. Please ensure you've provided a reason.");
  }

  const isPending = localStatus === "PENDING";

  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} title="Referral Details"
      onBack={onBack} onLogout={onLogout}>
      <div className="flex flex-col gap-5">
        {/* Status header */}
        <Card className="p-5">
          <div className="flex items-center justify-between flex-wrap gap-2 mb-1">
            <p className="text-xs font-mono text-muted-foreground" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              {ref.id}
            </p>
            <p className="text-xs text-muted-foreground">{ref.receivedAt}</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap mt-2">
            <UrgencyBadge level={ref.urgency} />
            <StatusBadge status={localStatus!} />
          </div>
        </Card>

        {/* Patient info */}
        <Card className="p-5">
          <SectionLabel>Patient Information</SectionLabel>
          <div className="flex items-center gap-3 mb-4">
            <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold shrink-0">
              {ref.patient.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
            </div>
            <div>
              <p className="font-bold text-foreground">{ref.patient.name}</p>
              <p className="text-sm text-muted-foreground">{ref.patient.age} years · {ref.patient.sex === "M" ? "Male" : ref.patient.sex === "F" ? "Female" : ref.patient.sex}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Phone size={14} className="text-muted-foreground shrink-0" />
            <p className="text-sm text-foreground">{ref.patient.phone}</p>
          </div>
        </Card>

        {/* Clinical info */}
        <Card className="p-5">
          <SectionLabel>Clinical Presentation</SectionLabel>
          <div className="flex flex-col gap-3">
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">Chief Complaint</p>
              <p className="text-sm font-medium text-foreground leading-relaxed">{ref.chiefComplaint}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">Provisional Diagnosis</p>
              <p className="text-sm font-semibold text-foreground">{ref.provisionalDiagnosis}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">Vital Signs on Arrival</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {Object.entries(ref.vitals).map(([k, v]) => (
                  <div key={k} className="bg-secondary rounded-lg p-2.5">
                    <p className="text-xs text-muted-foreground capitalize">{k === "spo2" ? "SpO₂" : k === "rr" ? "Resp. Rate" : k.charAt(0).toUpperCase() + k.slice(1)}</p>
                    <p className="text-sm font-bold text-foreground font-mono" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{v}</p>
                  </div>
                ))}
              </div>
            </div>
            {ref.notes && (
              <div>
                <p className="text-xs text-muted-foreground mb-0.5">Clinician Notes</p>
                <p className="text-sm text-foreground leading-relaxed bg-muted rounded-lg p-3">{ref.notes}</p>
              </div>
            )}
          </div>
        </Card>

        {/* Referring facility */}
        <Card className="p-5">
          <SectionLabel>Referring Facility</SectionLabel>
          <div className="flex items-start gap-3">
            <Building2 size={18} className="text-muted-foreground shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-foreground">{ref.referringFacility}</p>
              <p className="text-sm text-muted-foreground mt-0.5">Referred by: {ref.referringClinician}</p>
            </div>
          </div>
        </Card>

        {/* Actions */}
        {isPending && (
          <Card className="p-5">
            <SectionLabel>Your Response</SectionLabel>
            <p className="text-sm text-muted-foreground mb-4">
              Review the referral details above before responding. The referring clinician will be notified of your decision.
            </p>
            <div className="flex flex-col gap-3">
              <Btn size="lg" onClick={() => handleAction("accept", "ACCEPTED")}
                loading={actionLoading === "accept"} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                <CheckCircle2 size={18} /> Accept Referral
              </Btn>
              <Btn size="lg" variant="secondary" onClick={() => handleAction("info", "PENDING")}
                loading={actionLoading === "info"}>
                <MessageSquare size={18} /> Request More Information
              </Btn>
              <Btn size="lg" variant="destructive" onClick={() => handleAction("decline", "DECLINED")}
                loading={actionLoading === "decline"}>
                <XCircle size={18} /> Decline Referral
              </Btn>
            </div>
          </Card>
        )}

        {!isPending && (
          <AlertBox type={localStatus === "ACCEPTED" || localStatus === "COMPLETED" ? "success" : localStatus === "DECLINED" ? "error" : "info"}>
            {localStatus === "ACCEPTED" && "You have accepted this referral. Prepare your team for the incoming patient."}
            {localStatus === "DECLINED" && "You have declined this referral. The referring facility has been notified."}
            {localStatus === "IN_TRANSIT" && "Patient is currently en route to your facility."}
            {localStatus === "COMPLETED" && "This referral has been completed and closed."}
          </AlertBox>
        )}
      </div>
    </AppShell>
  );
}

// ─── Screen: Forgot Password ──────────────────────────────────────────────────
function ForgotPasswordScreen({ onBack, theme, onThemeToggle }: {
  onBack: () => void; theme: Theme; onThemeToggle: () => void;
}) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.includes("@")) { setError("Please enter a valid email address"); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    setSent(true);
  }

  if (sent) return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center text-center gap-5">
          <div className="size-16 rounded-full bg-primary/10 flex items-center justify-center">
            <CheckCircle2 size={32} className="text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Check your email</h1>
            <p className="text-muted-foreground text-sm mt-2">
              We've sent a password reset link to <strong className="text-foreground">{email}</strong>. The link expires in 30 minutes.
            </p>
          </div>
          <AlertBox type="info">
            If you don't see the email, check your spam folder. For urgent access, contact your facility administrator or the MediRoute helpdesk.
          </AlertBox>
          <Btn size="lg" onClick={onBack}>Back to Sign In</Btn>
          <button type="button" onClick={() => setSent(false)}
            className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1 min-h-[44px]">
            <RefreshCw size={14} /> Resend reset link
          </button>
        </div>
      </div>
    </AuthShell>
  );

  return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-md">
        <button type="button" onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 min-h-[44px]">
          <ArrowLeft size={16} /> Back to Sign In
        </button>
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-foreground">Reset your password</h1>
          <p className="text-muted-foreground text-sm mt-1.5">
            Enter the email address linked to your facility account. We'll send a secure reset link.
          </p>
        </div>
        <Card className="p-6">
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <Field label="Email address" required error={error}>
              <Input type="email" placeholder="admin@yourhospital.ng" value={email}
                onChange={e => { setEmail(e.target.value); setError(""); }}
                autoComplete="email" aria-invalid={!!error} />
            </Field>
            <Btn type="submit" size="lg" loading={loading}>
              {loading ? "Sending…" : "Send Reset Link"}
            </Btn>
          </form>
        </Card>
      </div>
    </AuthShell>
  );
}

// ─── Screen: Create Account ────────────────────────────────────────────────────
const LGA_MAP: Record<string, string[]> = {
  "Abuja (FCT)": ["Abaji", "AMAC", "Bwari", "Gwagwalada", "Kuje", "Kwali"],
  Lagos: ["Alimosho", "Ajeromi-Ifelodun", "Kosofe", "Mushin", "Oshodi-Isolo", "Agege", "Ifako-Ijaiye", "Surulere", "Amuwo-Odofin", "Lagos Mainland", "Apapa", "Shomolu", "Ikeja", "Eti-Osa", "Badagry", "Ibeju-Lekki", "Epe", "Ikorodu"],
  Kano: ["Dala", "Gwale", "Kano Municipal", "Tarauni", "Nassarawa", "Fagge"],
  Rivers: ["Port Harcourt", "Obio-Akpor", "Okrika", "Khana", "Tai"],
  Oyo: ["Ibadan North", "Ibadan South-East", "Ibadan South-West", "Ibadan North-East", "Ibadan North-West", "Egbeda"],
};
const STATES = Object.keys(LGA_MAP);

type FacilityForm = {
  facilityName: string; facilityType: string; regNumber: string;
  state: string; lga: string; address: string;
  contactName: string; contactRole: string; phone: string; email: string;
  password: string; confirmPassword: string;
};

function CreateAccountScreen({ onBack, onSuccess, theme, onThemeToggle }: {
  onBack: () => void; onSuccess: (email: string) => void; theme: Theme; onThemeToggle: () => void;
}) {
  const [form, setForm] = useState<FacilityForm>({
    facilityName: "", facilityType: "", regNumber: "", state: "", lga: "", address: "",
    contactName: "", contactRole: "", phone: "", email: "", password: "", confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [showCPw, setShowCPw] = useState(false);

  const set = (k: keyof FacilityForm) => (v: string) => {
    setForm(p => { const n = { ...p, [k]: v }; if (k === "state") n.lga = ""; return n; });
    setErrors(p => ({ ...p, [k]: "" }));
  };

  const lgas = form.state ? LGA_MAP[form.state] ?? [] : [];

  function validate() {
    const e: Record<string, string> = {};
    if (!form.facilityName.trim()) e.facilityName = "Facility name is required";
    if (!form.facilityType) e.facilityType = "Please select the facility type";
    if (!form.state) e.state = "Please select your state";
    if (!form.lga) e.lga = "Please select your LGA";
    if (!form.contactName.trim()) e.contactName = "Contact person's name is required";
    if (!form.phone.trim()) e.phone = "Phone number is required";
    if (!form.email.includes("@")) e.email = "Please enter a valid email address";
    if (form.password.length < 8) e.password = "Password must be at least 8 characters";
    if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) { toast.error("Please correct the errors highlighted below"); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 2000));
    setLoading(false);
    onSuccess(form.email);
  }

  return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-lg">
        <button type="button" onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 min-h-[44px]">
          <ArrowLeft size={16} /> Back to Sign In
        </button>
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-foreground">Register Your Facility</h1>
          <p className="text-muted-foreground text-sm mt-1.5">Join the MediRoute NG referral network. All accounts are verified by the FMOH.</p>
        </div>

        <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
          <Card className="p-5">
            <SectionLabel>Facility Details</SectionLabel>
            <div className="flex flex-col gap-4">
              <Field label="Facility Name" required error={errors.facilityName}>
                <Input placeholder="e.g. Awgu General Hospital" value={form.facilityName} onChange={e => set("facilityName")(e.target.value)} />
              </Field>
              <Field label="Facility Type" required error={errors.facilityType}>
                <Select value={form.facilityType} onChange={e => set("facilityType")(e.target.value)} aria-invalid={!!errors.facilityType}>
                  <option value="">Select type…</option>
                  {["Primary Health Centre (PHC)", "General Hospital", "Specialist Centre", "State Teaching Hospital", "Federal Teaching Hospital", "Private Hospital / Clinic"].map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </Select>
              </Field>
              <Field label="CAC / HEFAMAA Registration Number" hint="Optional — but required for final verification">
                <MonoInput placeholder="e.g. RC-123456" value={form.regNumber} onChange={e => set("regNumber")(e.target.value)} />
              </Field>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="State" required error={errors.state}>
                  <Select value={form.state} onChange={e => set("state")(e.target.value)} aria-invalid={!!errors.state}>
                    <option value="">Select state…</option>
                    {STATES.map(s => <option key={s} value={s}>{s}</option>)}
                  </Select>
                </Field>
                <Field label="LGA" required error={errors.lga}>
                  <Select value={form.lga} onChange={e => set("lga")(e.target.value)}
                    disabled={!form.state} aria-invalid={!!errors.lga}>
                    <option value="">{form.state ? "Select LGA…" : "Select state first"}</option>
                    {lgas.map(l => <option key={l} value={l}>{l}</option>)}
                  </Select>
                </Field>
              </div>
              <Field label="Street Address">
                <Input placeholder="Full street address" value={form.address} onChange={e => set("address")(e.target.value)} />
              </Field>
            </div>
          </Card>

          <Card className="p-5">
            <SectionLabel>Primary Contact Officer</SectionLabel>
            <div className="flex flex-col gap-4">
              <Field label="Full Name" required error={errors.contactName}>
                <Input placeholder="Name of the account administrator" value={form.contactName} onChange={e => set("contactName")(e.target.value)} />
              </Field>
              <Field label="Job Title / Role" hint="e.g. Medical Officer, Head of Administration">
                <Input placeholder="Your role at the facility" value={form.contactRole} onChange={e => set("contactRole")(e.target.value)} />
              </Field>
              <Field label="Phone Number" required error={errors.phone}>
                <Input type="tel" placeholder="+234 800 000 0000" value={form.phone} onChange={e => set("phone")(e.target.value)} />
              </Field>
            </div>
          </Card>

          <Card className="p-5">
            <SectionLabel>Login Credentials</SectionLabel>
            <div className="flex flex-col gap-4">
              <Field label="Email Address" required error={errors.email} hint="This will be your login email and where we send important notifications">
                <Input type="email" placeholder="admin@yourhospital.ng" value={form.email} onChange={e => set("email")(e.target.value)} autoComplete="email" />
              </Field>
              <Field label="Password" required error={errors.password} hint="Minimum 8 characters">
                <div className="relative">
                  <Input type={showPw ? "text" : "password"} placeholder="Create a strong password"
                    value={form.password} onChange={e => set("password")(e.target.value)} className="pr-12" autoComplete="new-password" />
                  <button type="button" onClick={() => setShowPw(v => !v)} aria-label={showPw ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-muted-foreground hover:text-foreground rounded">
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </Field>
              <Field label="Confirm Password" required error={errors.confirmPassword}>
                <div className="relative">
                  <Input type={showCPw ? "text" : "password"} placeholder="Repeat your password"
                    value={form.confirmPassword} onChange={e => set("confirmPassword")(e.target.value)} className="pr-12" />
                  <button type="button" onClick={() => setShowCPw(v => !v)} aria-label={showCPw ? "Hide password" : "Show password"}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-muted-foreground hover:text-foreground rounded">
                    {showCPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </Field>
            </div>
          </Card>

          <Btn type="submit" size="lg" loading={loading}>
            {loading ? "Submitting registration…" : "Submit Facility Registration"}
          </Btn>
        </form>
      </div>
    </AuthShell>
  );
}

// ─── Screen: Verify Email ─────────────────────────────────────────────────────
function VerifyEmailScreen({ email, onBack, onVerified, theme, onThemeToggle }: {
  email: string; onBack: () => void; onVerified: () => void; theme: Theme; onThemeToggle: () => void;
}) {
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [resendTimer, setResendTimer] = useState(0);
  const [loading, setLoading] = useState(false);
  const refs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const id = setTimeout(() => setResendTimer(t => t - 1), 1000);
    return () => clearTimeout(id);
  }, [resendTimer]);

  function handleDigit(i: number, val: string) {
    const d = val.replace(/\D/, "").slice(-1);
    const next = [...code]; next[i] = d; setCode(next);
    if (d && i < 5) refs.current[i + 1]?.focus();
  }

  function handleKey(i: number, e: React.KeyboardEvent) {
    if (e.key === "Backspace" && !code[i] && i > 0) refs.current[i - 1]?.focus();
  }

  function handlePaste(e: React.ClipboardEvent) {
    const digits = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6).split("");
    setCode([...digits, ...Array(6 - digits.length).fill("")]);
    refs.current[Math.min(digits.length, 5)]?.focus();
    e.preventDefault();
  }

  async function handleVerify() {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    onVerified();
  }

  function handleResend() {
    setResendTimer(60);
    setCode(["", "", "", "", "", ""]);
    refs.current[0]?.focus();
    toast.info("A new verification code has been sent.");
  }

  const fullCode = code.join("");

  return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-md">
        <button type="button" onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 min-h-[44px]">
          <ArrowLeft size={16} /> Back
        </button>
        <div className="text-center mb-8">
          <div className="size-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Shield size={28} className="text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Verify your email</h1>
          <p className="text-muted-foreground text-sm mt-2">
            We sent a 6-digit code to <strong className="text-foreground">{email}</strong>.
            Enter it below — the code expires in 10 minutes.
          </p>
        </div>

        <Card className="p-6">
          <div className="flex gap-2 justify-center mb-6" onPaste={handlePaste}>
            {code.map((d, i) => (
              <input key={i}
                ref={el => { refs.current[i] = el; }}
                type="text" inputMode="numeric" maxLength={1} value={d}
                onChange={e => handleDigit(i, e.target.value)}
                onKeyDown={e => handleKey(i, e)}
                aria-label={`Digit ${i + 1} of 6`}
                className={`size-12 rounded-xl text-center text-xl font-bold border-2 bg-input-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all ${
                  d ? "border-primary" : "border-border"
                }`}
              />
            ))}
          </div>

          <Btn size="lg" onClick={handleVerify} disabled={fullCode.length < 6} loading={loading}>
            {loading ? "Verifying…" : "Verify Email"}
          </Btn>

          <div className="text-center mt-4">
            {resendTimer > 0 ? (
              <p className="text-sm text-muted-foreground">
                Resend available in{" "}
                <span className="font-bold text-primary font-mono" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  {String(Math.floor(resendTimer / 60)).padStart(2, "0")}:{String(resendTimer % 60).padStart(2, "0")}
                </span>
              </p>
            ) : (
              <button type="button" onClick={handleResend}
                className="text-sm text-primary font-semibold hover:underline min-h-[44px] flex items-center gap-1.5 mx-auto">
                <RefreshCw size={14} /> Resend verification code
              </button>
            )}
          </div>
        </Card>
      </div>
    </AuthShell>
  );
}

// ─── Screen: Account Created Success ─────────────────────────────────────────
function AccountSuccessScreen({ onLogin, theme, onThemeToggle }: {
  onLogin: () => void; theme: Theme; onThemeToggle: () => void;
}) {
  return (
    <AuthShell theme={theme} onThemeToggle={onThemeToggle}>
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center text-center gap-5">
          <div className="size-20 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
            <CheckCircle2 size={40} className="text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Registration Submitted!</h1>
            <p className="text-muted-foreground text-sm mt-2 leading-relaxed">
              Your facility registration has been submitted for FMOH verification. You will receive a confirmation email within <strong>1–2 working days</strong>.
            </p>
          </div>
          <AlertBox type="info">
            While you wait, you can contact the MediRoute NG helpdesk at <strong>0800-MEDIROUTE</strong> if you have any questions about your application.
          </AlertBox>
          <Btn size="lg" onClick={onLogin}>
            Back to Sign In
          </Btn>
        </div>
      </div>
    </AuthShell>
  );
}

// ─── Dashboard helpers ────────────────────────────────────────────────────────
function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return `${parts[0][0]}.${parts[parts.length - 1][0]}.`;
  return `${parts[0][0]}.`;
}

function patientLine(p: { name: string; age: number; sex: string }, specialty: string) {
  return `${getInitials(p.name)}, ${p.age}${p.sex} — ${specialty}`;
}

// Figma urgency label: IMMEDIATE → CRITICAL
const DASH_URGENCY: Record<UrgencyLevel, { label: string; cls: string }> = {
  IMMEDIATE: { label: "CRITICAL", cls: "bg-red-900/60 text-red-400 border border-red-700/60" },
  URGENT:    { label: "URGENT",   cls: "bg-amber-900/50 text-amber-400 border border-amber-700/50" },
  ROUTINE:   { label: "ROUTINE",  cls: "bg-emerald-900/40 text-emerald-400 border border-emerald-700/40" },
};

const DASH_STATUS: Record<ReferralStatus, { label: string; cls: string }> = {
  PENDING:    { label: "PENDING",    cls: "text-amber-400" },
  ACCEPTED:   { label: "ACCEPTED",   cls: "text-emerald-400" },
  DECLINED:   { label: "DECLINED",   cls: "text-red-400" },
  IN_TRANSIT: { label: "ARRIVED",    cls: "text-blue-400" },
  COMPLETED:  { label: "COMPLETED",  cls: "text-slate-400" },
};

type DashFilter = "ALL" | ReferralStatus;

// ─── Screen: Dashboard ────────────────────────────────────────────────────────
function DashboardScreen({ onNewReferral, onViewDetail, onManageReferrals, onNewConsult, onViewConsult, onOpenConsultInbox, onLogout, theme, onThemeToggle, username }: {
  onNewReferral: () => void; onViewDetail: (id: string) => void;
  onManageReferrals: () => void; onNewConsult: () => void;
  onViewConsult: (id: string) => void; onOpenConsultInbox: () => void;
  onLogout: () => void; theme: Theme; onThemeToggle: () => void; username: string;
}) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<DashFilter>("ALL");

  // Stats
  const pending   = MOCK_REFERRALS.filter(r => r.status === "PENDING").length;
  const accepted  = MOCK_REFERRALS.filter(r => r.status === "ACCEPTED").length;
  const declined  = MOCK_REFERRALS.filter(r => r.status === "DECLINED").length;
  const completed = MOCK_REFERRALS.filter(r => r.status === "COMPLETED").length;
  const openConsults = MOCK_CONSULTS.filter(c => c.status === "AWAITING").length;

  const filtered = MOCK_REFERRALS.filter(r => {
    const q = search.toLowerCase();
    const matchSearch = !q
      || r.patient.name.toLowerCase().includes(q)
      || r.id.toLowerCase().includes(q)
      || r.specialty.toLowerCase().includes(q)
      || r.receivingFacility.toLowerCase().includes(q);
    const matchFilter = filter === "ALL" || r.status === filter;
    return matchSearch && matchFilter;
  });

  const FILTERS: { key: DashFilter; label: string; count: number }[] = [
    { key: "ALL",       label: "All",       count: MOCK_REFERRALS.length },
    { key: "PENDING",   label: "Pending",   count: pending },
    { key: "ACCEPTED",  label: "Accepted",  count: accepted },
    { key: "IN_TRANSIT",label: "En Route",  count: MOCK_REFERRALS.filter(r=>r.status==="IN_TRANSIT").length },
    { key: "DECLINED",  label: "Declined",  count: declined },
    { key: "COMPLETED", label: "Completed", count: completed },
  ];

  // Derive a display label from username: uppercase, max 12 chars
  const userLabel = (username || "USER").toUpperCase().slice(0, 12);

  // Stat card — uses theme tokens so it works in both light and dark
  function StatCard({ value, label, color }: { value: number; label: string; color: string }) {
    return (
      <div className="flex-1 min-w-[120px] rounded-[4px] p-4 flex flex-col gap-1 bg-card border border-border">
        <p className="text-[28px] font-bold leading-[1.5]"
          style={{ fontFamily: "'JetBrains Mono', monospace", color }}>{value}</p>
        <p className="text-[11.5px] tracking-[0.35px] uppercase text-muted-foreground">{label}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* ── Header ── */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-6 py-4 bg-card border-b border-border">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="size-7 rounded-[4px] flex items-center justify-center shrink-0 bg-primary">
              <svg className="size-[14px]" fill="none" viewBox="0 0 14 14">
                <path d="M12.8333 7H11.3867C11.1317 6.99945 10.8836 7.08243 10.6803 7.23623C10.477 7.39003 10.3297 7.6062 10.2608 7.85167L8.89 12.7283C8.88116 12.7586 8.86274 12.7852 8.8375 12.8042C8.8167 12.8231 8.78155 12.8333 8.75 12.8333C8.71845 12.8333 8.68774 12.8231 8.6625 12.8042C8.63726 12.7852 8.61884 12.7586 8.61 12.7283L5.39 1.27167C5.38116 1.24138 5.36274 1.21477 5.3375 1.19583C5.31226 1.1769 5.28155 1.16667 5.25 1.16667C5.21845 1.16667 5.18774 1.1769 5.1625 1.19583C5.13726 1.21477 5.11884 1.24138 5.11 1.27167L3.73917 6.14833C3.6706 6.39284 3.52414 6.6083 3.322 6.76201C3.11987 6.91571 2.8731 6.99927 2.61917 7H1.16667"
                  stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
              </svg>
            </div>
            <span className="text-[16px] font-semibold tracking-[-0.32px] text-foreground">MediRoute NG</span>
          </div>
          {/* Role breadcrumb shows username */}
          <span className="text-[11px] uppercase tracking-[0.5px] text-muted-foreground hidden sm:inline"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}>
            / {userLabel}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Online dot + username */}
          <div className="flex items-center gap-2">
            <div className="size-[6px] rounded-full bg-emerald-500" />
            <span className="text-[11px] text-muted-foreground hidden sm:inline"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              {userLabel}
            </span>
          </div>
          <ThemeToggle theme={theme} onToggle={onThemeToggle} />
          <button type="button" onClick={onLogout} aria-label="Sign out"
            className="p-2 rounded-lg min-w-[44px] min-h-[44px] flex items-center justify-center transition-all text-muted-foreground hover:text-foreground hover:bg-secondary">
            <LogOut size={16} />
          </button>
        </div>
      </header>

      {/* ── Page body ── */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 py-8 flex flex-col gap-8">

        {/* Title row — username as facility name */}
        <div className="flex items-center justify-between">
          <h1 className="text-[25.6px] font-bold tracking-[-0.64px] text-foreground capitalize">
            {username || "Dashboard"}
          </h1>
          <button type="button" onClick={onNewReferral}
            className="flex items-center gap-2 px-4 py-2 rounded-[4px] text-white text-sm font-semibold transition-opacity hover:opacity-90 min-h-[36px] bg-primary">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <path d="M3.125 7.5H11.875" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
              <path d="M7.5 3.125V11.875" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
            </svg>
            New Request
          </button>
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search patient name, ref ID, specialty…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full rounded-[4px] pl-10 pr-4 py-3 text-sm outline-none transition-all bg-card border border-border text-foreground placeholder:text-muted-foreground focus:ring-2 focus:ring-ring"
          />
          {search && (
            <button type="button" onClick={() => setSearch("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X size={14} />
            </button>
          )}
        </div>

        {/* Stats row */}
        <div className="flex flex-wrap gap-4">
          <StatCard value={pending}      label="Pending"       color="#f6a623" />
          <StatCard value={accepted}     label="Accepted"      color="#00c875" />
          <StatCard value={declined}     label="Declined"      color="#ef4444" />
          <StatCard value={completed}    label="Completed"     color="#1d6ef5" />
          <StatCard value={openConsults} label="Open Consults" color="#a78bfa" />
        </div>

        {/* ── Referrals ── */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-[11px] font-bold uppercase tracking-[0.8px] text-muted-foreground">
              Referrals
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-secondary text-foreground"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              {filtered.length}
            </span>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
            {FILTERS.map(({ key, label, count }) => {
              const active = filter === key;
              return (
                <button key={key} type="button" onClick={() => setFilter(key)}
                  className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-[4px] text-xs font-semibold transition-all min-h-[32px] ${
                    active
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground hover:text-foreground border border-border"
                  }`}>
                  {label}
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    active ? "bg-white/20 text-white" : "bg-border text-muted-foreground"
                  }`}
                    style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Referral cards */}
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <ClipboardList size={36} className="mb-3 opacity-30" />
              <p className="text-sm font-semibold">No referrals found</p>
              {search && <p className="text-xs mt-1">Try clearing your search</p>}
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {filtered.map(ref => {
                const urgCfg  = DASH_URGENCY[ref.urgency];
                const statCfg = DASH_STATUS[ref.status];
                return (
                  <button key={ref.id} type="button" onClick={() => onViewDetail(ref.id)}
                    className="w-full text-left rounded-[4px] p-4 transition-all hover:border-primary/60 bg-card border border-border">
                    {/* Top row */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-[3px] uppercase tracking-wide ${urgCfg.cls}`}>
                          {urgCfg.label}
                        </span>
                        <span className="text-[10px] text-muted-foreground"
                          style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                          {ref.id}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {ref.status === "ACCEPTED"   && <CheckCircle2 size={12} style={{ color: "#00c875" }} />}
                        {ref.status === "PENDING"    && <Clock size={12} style={{ color: "#f6a623" }} />}
                        {ref.status === "IN_TRANSIT" && <Activity size={12} style={{ color: "#1d6ef5" }} />}
                        {ref.status === "DECLINED"   && <XCircle size={12} style={{ color: "#ef4444" }} />}
                        {ref.status === "COMPLETED"  && <CheckCheck size={12} className="text-muted-foreground" />}
                        <span className={`text-[11px] font-bold ${statCfg.cls}`}>{statCfg.label}</span>
                      </div>
                    </div>
                    <p className="text-sm font-semibold text-foreground mb-1">
                      {patientLine(ref.patient, ref.specialty)}
                    </p>
                    <p className="text-[11.5px] text-muted-foreground">
                      {ref.receivingFacility} · {ref.receivedAt}
                    </p>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Tele-Consults ── */}
        <div>
          {/* Section header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-[0.8px] text-muted-foreground">Tele-Consults</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-secondary text-foreground"
                style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                {MOCK_CONSULTS.length}
              </span>
              {MOCK_CONSULTS.filter(c => c.status === "AWAITING").length > 0 && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(246,166,35,0.15)", color: "#f6a623" }}>
                  {MOCK_CONSULTS.filter(c => c.status === "AWAITING").length} awaiting
                </span>
              )}
            </div>
            <button type="button" onClick={onOpenConsultInbox}
              className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
              View pool <ChevronRight size={13} />
            </button>
          </div>

          {/* Recent consult cards */}
          <div className="flex flex-col gap-2">
            {MOCK_CONSULTS.slice(0, 3).map(c => {
              const lastMsg = [...c.messages].reverse().find(m => m.sender !== "SYSTEM");
              const statusColor: Record<ConsultStatus, string> = {
                AWAITING: "#f6a623", ACTIVE: "#1d6ef5", RESOLVED: "#00c875",
                FOLLOW_UP: "#a78bfa", CONVERTED: "#64748b",
              };
              const statusLabel: Record<ConsultStatus, string> = {
                AWAITING: "AWAITING", ACTIVE: "ACTIVE", RESOLVED: "RESOLVED",
                FOLLOW_UP: "FOLLOW-UP", CONVERTED: "CONVERTED",
              };
              return (
                <button key={c.id} type="button" onClick={() => onViewConsult(c.id)}
                  className="w-full text-left rounded-[4px] p-4 bg-card border border-border hover:border-primary/40 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] text-muted-foreground" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</span>
                    <span className="text-[11px] font-bold" style={{ color: statusColor[c.status] }}>{statusLabel[c.status]}</span>
                  </div>
                  <p className="text-sm font-semibold text-foreground mb-1">{patientLine(c.patient, c.specialty)}</p>
                  {lastMsg && (
                    <div className="flex items-start gap-2">
                      <MessageSquare size={11} className="shrink-0 mt-0.5 text-muted-foreground" />
                      <p className="text-[12px] text-muted-foreground line-clamp-1">{lastMsg.text}</p>
                    </div>
                  )}
                  <p className="text-[11px] text-muted-foreground mt-1">{c.pool} · {c.createdAt}</p>
                </button>
              );
            })}
          </div>

          {/* Dashed new-referral CTA */}
          <button type="button" onClick={onNewReferral}
            className="mt-4 w-full flex items-center justify-center gap-2 py-4 rounded-[4px] border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-primary/50 transition-all">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2.91667 7H11.0833" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
              <path d="M7 2.91667V11.0833" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
            </svg>
            <span className="text-[13px] font-medium">New referral</span>
          </button>
        </div>

        {/* Tele-consult prominent CTA */}
        <div className="rounded-xl p-5 flex items-center justify-between gap-4 border"
          style={{ background: "rgba(167,139,250,0.08)", borderColor: "rgba(167,139,250,0.25)" }}>
          <div>
            <p className="text-sm font-bold mb-1" style={{ color: "#a78bfa" }}>Request a Tele-Consultation</p>
            <p className="text-xs text-muted-foreground">
              Ask a specialist before referring. Reduces unnecessary transfers by up to 35%.
            </p>
          </div>
          <button type="button" onClick={onNewConsult}
            className="shrink-0 flex items-center gap-2 px-4 py-2 rounded-[4px] text-sm font-semibold transition-opacity hover:opacity-90 min-h-[40px] text-[#0b0f14]"
            style={{ background: "#a78bfa" }}>
            <Video size={15} /> Start Consult
          </button>
        </div>

      </div>
    </div>
  );
}

// ─── Consult status helpers ───────────────────────────────────────────────────
const CONSULT_STATUS_COLOR: Record<ConsultStatus, string> = {
  AWAITING: "#f6a623", ACTIVE: "#1d6ef5", RESOLVED: "#00c875",
  FOLLOW_UP: "#a78bfa", CONVERTED: "#64748b",
};
const CONSULT_STATUS_LABEL: Record<ConsultStatus, string> = {
  AWAITING: "Awaiting Specialist", ACTIVE: "In Discussion",
  RESOLVED: "Resolved", FOLLOW_UP: "Follow-Up", CONVERTED: "Converted to Referral",
};

const SPECIALTY_POOLS = [
  "All Pools",
  "Abuja OBS/GYN Pool", "Abuja Paediatrics Pool", "Abuja Internal Medicine Pool",
  "Abuja Dermatology Pool", "Abuja Cardiology Pool", "Abuja Neurology Pool",
  "Enugu Paediatrics Pool", "Lagos Surgery Pool",
];

// ─── Consult Workspace (replaces both Inbox + Thread screens) ────────────────
function ConsultWorkspaceScreen({ consultId, onBack, onNewConsult, onConvertToReferral, theme, onThemeToggle, onLogout, username }: {
  consultId?: string; onBack: () => void; onNewConsult: () => void;
  onConvertToReferral: (c: Consult) => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void; username: string;
}) {
  const initId = consultId ?? MOCK_CONSULTS[0]?.id ?? "";
  const [selectedId, setSelectedId] = useState(initId);
  const [showMobileThread, setShowMobileThread] = useState(!!consultId);

  // Per-thread message and status state so switching threads is instant
  const [messagesMap, setMessagesMap] = useState<Record<string, ConsultMessage[]>>(() => {
    const m: Record<string, ConsultMessage[]> = {};
    MOCK_CONSULTS.forEach(c => { m[c.id] = c.messages; });
    return m;
  });
  const [statusMap, setStatusMap] = useState<Record<string, ConsultStatus>>(() => {
    const m: Record<string, ConsultStatus> = {};
    MOCK_CONSULTS.forEach(c => { m[c.id] = c.status; });
    return m;
  });
  const [input, setInput] = useState("");
  const [showClosure, setShowClosure] = useState(false);
  const [closing, setClosing] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const active = MOCK_CONSULTS.find(c => c.id === selectedId) ?? MOCK_CONSULTS[0];
  const messages = messagesMap[selectedId] ?? [];
  const localStatus = statusMap[selectedId] ?? "AWAITING";
  const isClosed = localStatus === "RESOLVED" || localStatus === "CONVERTED";

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [selectedId, messages.length]);

  function selectThread(id: string) {
    setSelectedId(id);
    setShowClosure(false);
    setInput("");
    setShowMobileThread(true);
  }

  function sendMessage() {
    if (!input.trim() || !active) return;
    const msg: ConsultMessage = {
      id: `m-${Date.now()}`,
      sender: "REQUESTER",
      senderName: username || "You",
      text: input.trim(),
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessagesMap(p => ({ ...p, [selectedId]: [...(p[selectedId] ?? []), msg] }));
    if (localStatus === "AWAITING") setStatusMap(p => ({ ...p, [selectedId]: "ACTIVE" }));
    setInput("");
  }

  async function closeThread(action: "local" | "followup" | "convert") {
    setClosing(action);
    await new Promise(r => setTimeout(r, 900));
    if (action === "convert") {
      onConvertToReferral(active!);
      return;
    }
    const ns: ConsultStatus = action === "local" ? "RESOLVED" : "FOLLOW_UP";
    const sys: ConsultMessage = {
      id: `sys-${Date.now()}`, sender: "SYSTEM", senderName: "System",
      text: `Thread closed — ${action === "local" ? "Manage Locally" : "Follow-up Needed"}`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessagesMap(p => ({ ...p, [selectedId]: [...(p[selectedId] ?? []), sys] }));
    setStatusMap(p => ({ ...p, [selectedId]: ns }));
    setClosing(null);
    setShowClosure(false);
    toast.success(action === "local" ? "Marked as Manage Locally — no transfer needed." : "Marked for follow-up.");
  }

  const userLabel = (username || "LUTH").toUpperCase().slice(0, 12);

  // ── Sidebar item ───────────────────────────────────────────────────────────
  function SidebarItem({ c }: { c: typeof MOCK_CONSULTS[0] }) {
    const st = statusMap[c.id] ?? c.status;
    const isActive = selectedId === c.id;
    const isCl = st === "RESOLVED" || st === "CONVERTED";
    const statusLabel = isCl ? "CLOSED" : st === "FOLLOW_UP" ? "FOLLOW-UP" : c.urgency === "IMMEDIATE" ? "CRITICAL" : c.urgency;
    const statusCol = isCl ? "#00c875" : "#f6a623";
    return (
      <button type="button" onClick={() => selectThread(c.id)}
        className="w-full text-left transition-colors hover:opacity-90"
        style={{
          background: isActive ? "#1a2235" : "transparent",
          borderBottom: "0.667px solid rgba(255,255,255,0.08)",
          padding: "14px 16px",
        }}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px]" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>{c.id}</span>
          <span className="text-[9px] font-medium" style={{ color: statusCol, fontFamily: "'JetBrains Mono', monospace" }}>{statusLabel}</span>
        </div>
        <p className="text-[13.28px] font-semibold" style={{ color: "#e2e8f0" }}>
          {getInitials(c.patient.name)}, {c.patient.age}{c.patient.sex}
        </p>
        <p className="text-[11.52px] mt-0.5" style={{ color: "#64748b" }}>{c.specialty} · {c.createdAt}</p>
      </button>
    );
  }

  // ── Message bubble ─────────────────────────────────────────────────────────
  function MsgBubble({ msg }: { msg: ConsultMessage }) {
    if (msg.sender === "SYSTEM") {
      return (
        <div className="flex justify-center my-1">
          <span className="text-[11px] px-3 py-1 rounded-full" style={{ color: "#64748b", background: "#1a2235" }}>
            {msg.text} · {msg.time}
          </span>
        </div>
      );
    }
    const isReq = msg.sender === "REQUESTER";
    const accent   = isReq ? "#a78bfa" : "#1d6ef5";
    const avatarBg = isReq ? "rgba(167,139,250,0.13)" : "rgba(29,110,245,0.13)";
    const initials = msg.senderName.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
    return (
      <div className="flex gap-3 items-start">
        <div className="size-8 rounded-full flex items-center justify-center shrink-0 text-[11.2px] font-bold"
          style={{ background: avatarBg, color: accent }}>
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-[12.48px] font-semibold" style={{ color: "#e2e8f0" }}>{msg.senderName}</span>
            <span className="text-[10px]" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>
              {isReq ? "Referring PHC" : "Specialist"} · {msg.time}
            </span>
          </div>
          <div className="rounded-[4px]" style={{
            background: "#1a2235",
            borderLeft: `2.667px solid ${accent}`,
            padding: "11px 14.67px",
          }}>
            <p className="text-[13.6px] leading-[1.6]" style={{ color: "#e2e8f0" }}>{msg.text}</p>
          </div>
        </div>
      </div>
    );
  }

  // ── Thread panel ───────────────────────────────────────────────────────────
  function ThreadPanel() {
    if (!active) return null;
    const urg = active.urgency === "IMMEDIATE" ? "CRITICAL" : active.urgency;
    return (
      <div className="flex flex-col flex-1 min-h-0">
        {/* Thread header */}
        <div className="shrink-0 flex items-center justify-between px-6"
          style={{ borderBottom: "0.667px solid rgba(255,255,255,0.08)", paddingTop: 16, paddingBottom: 16.667 }}>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[15.2px] font-semibold" style={{ color: "#e2e8f0" }}>
                {getInitials(active.patient.name)}, {active.patient.age}{active.patient.sex} — {active.specialty}
              </span>
              <span className="text-[9px] rounded-[4px] px-1.5 py-1"
                style={{ background: "rgba(246,166,35,0.13)", color: "#f6a623", fontFamily: "'JetBrains Mono', monospace" }}>
                {urg}
              </span>
            </div>
            <p className="text-[12px] mt-0.5" style={{ color: "#64748b" }}>{active.pool} · Open {active.createdAt}</p>
          </div>
          <button type="button" onClick={() => setShowClosure(v => !v)}
            className="shrink-0 text-[12.48px] font-medium transition-colors hover:opacity-80"
            style={{
              border: "0.667px solid rgba(255,255,255,0.08)",
              borderRadius: 4, padding: "6.667px 12.667px", color: "#64748b",
            }}>
            Close thread
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">
          {messages.map(msg => <MsgBubble key={msg.id} msg={msg} />)}
          <div ref={bottomRef} />
        </div>

        {/* Closure action panel */}
        {showClosure && !isClosed && (
          <div className="shrink-0 px-6 py-4"
            style={{ borderTop: "0.667px solid rgba(255,255,255,0.08)", background: "#0d1520" }}>
            <p className="text-[11px] mb-3" style={{ color: "#64748b" }}>How should this thread close?</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button type="button" onClick={() => closeThread("local")} disabled={!!closing}
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-[4px] text-sm font-semibold transition-all disabled:opacity-50"
                style={{ background: "rgba(0,200,117,0.12)", border: "1px solid rgba(0,200,117,0.3)", color: "#00c875" }}>
                {closing === "local" ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                Manage Locally
              </button>
              <button type="button" onClick={() => closeThread("followup")} disabled={!!closing}
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-[4px] text-sm font-semibold transition-all disabled:opacity-50"
                style={{ background: "rgba(246,166,35,0.12)", border: "1px solid rgba(246,166,35,0.3)", color: "#f6a623" }}>
                {closing === "followup" ? <Loader2 size={14} className="animate-spin" /> : <CalendarClock size={14} />}
                Follow-up Needed
              </button>
              <button type="button" onClick={() => closeThread("convert")} disabled={!!closing}
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-[4px] text-sm font-semibold text-white transition-all disabled:opacity-50"
                style={{ background: "#1d6ef5" }}>
                {closing === "convert" ? <Loader2 size={14} className="animate-spin" /> : <ArrowUpRight size={14} />}
                Convert to Referral
              </button>
            </div>
          </div>
        )}

        {/* Input area */}
        {!isClosed ? (
          <div className="shrink-0 flex gap-3 items-end px-6"
            style={{ borderTop: "0.667px solid rgba(255,255,255,0.08)", paddingTop: 16.667, paddingBottom: 16 }}>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              placeholder="Type your response…"
              rows={2}
              className="flex-1 rounded-[4px] px-3 py-2.5 resize-none outline-none text-[13.6px] leading-[1.5]"
              style={{
                background: "#1a2235",
                border: "0.667px solid rgba(255,255,255,0.08)",
                color: "#e2e8f0",
                fontFamily: "Montserrat, sans-serif",
              }}
            />
            <button type="button" onClick={sendMessage} disabled={!input.trim()}
              className="rounded-[4px] p-[10px] shrink-0 disabled:opacity-40 transition-opacity hover:opacity-90"
              style={{ background: "#1d6ef5" }}>
              <Send size={16} color="white" />
            </button>
          </div>
        ) : (
          <div className="shrink-0 py-4 text-center"
            style={{ borderTop: "0.667px solid rgba(255,255,255,0.08)" }}>
            <p className="text-[12px]" style={{ color: "#64748b" }}>
              Thread closed · {CONSULT_STATUS_LABEL[localStatus]}
            </p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col" style={{ minHeight: "100vh", background: "#0b0f14" }}>
      {/* ── Header (matches Figma exactly) ── */}
      <header className="sticky top-0 z-30 shrink-0 flex items-center gap-4 px-6"
        style={{ background: "#0b0f14", borderBottom: "0.667px solid rgba(255,255,255,0.08)", paddingTop: 16, paddingBottom: 16.667 }}>
        <button type="button" onClick={showMobileThread ? () => setShowMobileThread(false) : onBack}
          aria-label="Back" className="shrink-0 flex items-center justify-center">
          <ArrowLeft size={16} style={{ color: "#64748b" }} />
        </button>
        {/* Logo */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="size-7 rounded-[4px] flex items-center justify-center" style={{ background: "#1d6ef5" }}>
            <svg className="size-[14px]" fill="none" viewBox="0 0 14 14">
              <path d="M12.8333 7H11.3867C11.1317 6.99945 10.8836 7.08243 10.6803 7.23623C10.477 7.39003 10.3297 7.6062 10.2608 7.85167L8.89 12.7283C8.88116 12.7586 8.86274 12.7852 8.8375 12.8042C8.8167 12.8231 8.78155 12.8333 8.75 12.8333C8.71845 12.8333 8.68774 12.8231 8.6625 12.8042C8.63726 12.7852 8.61884 12.7586 8.61 12.7283L5.39 1.27167C5.38116 1.24138 5.36274 1.21477 5.3375 1.19583C5.31226 1.1769 5.28155 1.16667 5.25 1.16667C5.21845 1.16667 5.18774 1.1769 5.1625 1.19583C5.13726 1.21477 5.11884 1.24138 5.11 1.27167L3.73917 6.14833C3.6706 6.39284 3.52414 6.6083 3.322 6.76201C3.11987 6.91571 2.8731 6.99927 2.61917 7H1.16667"
                stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.17" />
            </svg>
          </div>
          <span className="text-[16px] font-semibold tracking-[-0.32px]" style={{ color: "#e2e8f0" }}>MediRoute NG</span>
        </div>
        {/* Breadcrumb */}
        <span className="text-[11px] hidden sm:inline" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>
          / TELE-CONSULT POOL
        </span>
        {/* New consult shortcut */}
        <button type="button" onClick={onNewConsult}
          className="ml-2 hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-[4px] text-xs font-semibold shrink-0 transition-opacity hover:opacity-90"
          style={{ background: "rgba(167,139,250,0.15)", color: "#a78bfa" }}>
          <MessageSquarePlus size={13} /> New consult
        </button>
        {/* Right: online + user */}
        <div className="flex items-center gap-3 ml-auto">
          <div className="hidden sm:flex items-center gap-2">
            <div className="size-[6px] rounded-full" style={{ background: "#00c875" }} />
            <span className="text-[11px]" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>{userLabel}</span>
          </div>
          <ThemeToggle theme={theme} onToggle={onThemeToggle} />
          <button type="button" onClick={onLogout} aria-label="Sign out"
            className="p-2 rounded-lg min-w-[44px] min-h-[44px] flex items-center justify-center"
            style={{ color: "#64748b" }}>
            <LogOut size={16} />
          </button>
        </div>
      </header>

      {/* ── Two-panel body ── */}
      <div className="flex flex-1 overflow-hidden" style={{ height: "calc(100vh - 57px)" }}>

        {/* Left sidebar — always visible on md+, hidden on mobile when thread open */}
        <div className={`shrink-0 flex flex-col overflow-hidden ${showMobileThread ? "hidden md:flex" : "flex"}`}
          style={{ width: 288, borderRight: "0.667px solid rgba(255,255,255,0.08)" }}>
          {/* "SPECIALTY INBOX" label */}
          <div style={{ borderBottom: "0.667px solid rgba(255,255,255,0.08)", padding: "12px 16px 12.667px" }}>
            <p className="text-[10px] tracking-[0.8px]"
              style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase" }}>
              Specialty Inbox
            </p>
          </div>
          <div className="flex-1 overflow-y-auto">
            {MOCK_CONSULTS.map(c => <SidebarItem key={c.id} c={c} />)}
          </div>
          {/* New consult CTA at bottom of sidebar */}
          <button type="button" onClick={onNewConsult}
            className="shrink-0 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-opacity hover:opacity-80"
            style={{
              borderTop: "0.667px solid rgba(255,255,255,0.08)",
              color: "#64748b",
            }}>
            <MessageSquarePlus size={15} /> New consult request
          </button>
        </div>

        {/* Right thread panel — always on md+, shown only when thread selected on mobile */}
        <div className={`flex-1 min-w-0 flex flex-col overflow-hidden ${showMobileThread ? "flex" : "hidden md:flex"}`}>
          {active ? <ThreadPanel /> : (
            <div className="flex-1 flex flex-col items-center justify-center" style={{ color: "#64748b" }}>
              <MessageSquare size={40} className="mb-3 opacity-30" />
              <p className="text-sm font-semibold">Select a consult from the inbox</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

// Legacy thin wrappers kept so the router compiles without changes
function ConsultInboxScreen(props: Parameters<typeof ConsultWorkspaceScreen>[0]) {
  return <ConsultWorkspaceScreen {...props} />;
}
function ConsultThreadScreen({ consultId, onBack, onConvertToReferral, theme, onThemeToggle, onLogout, username }: {
  consultId: string; onBack: () => void; onConvertToReferral: (c: Consult) => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void; username: string;
}) {
  return (
    <ConsultWorkspaceScreen consultId={consultId} onBack={onBack} onNewConsult={() => {}} username={username}
      onConvertToReferral={onConvertToReferral} theme={theme} onThemeToggle={onThemeToggle} onLogout={onLogout} />
  );
}


// ─── Screen: New Consult Request ──────────────────────────────────────────────
type ConsultForm = {
  surname: string; givenNames: string; age: string; sex: string; phone: string;
  specialty: string; urgency: UrgencyLevel | "";
  clinicalQuestion: string; clinicalHistory: string;
  investigations: string; treatmentGiven: string;
  clinicianName: string;
};

const EMPTY_CONSULT_FORM: ConsultForm = {
  surname: "", givenNames: "", age: "", sex: "", phone: "",
  specialty: "", urgency: "",
  clinicalQuestion: "", clinicalHistory: "",
  investigations: "", treatmentGiven: "", clinicianName: "",
};

const CONSULT_SPECIALTIES = [
  "Cardiology", "Dermatology", "Emergency Medicine", "Endocrinology",
  "ENT", "General Surgery", "Haematology", "Internal Medicine", "Nephrology",
  "Neurology", "Obstetrics & Gynaecology", "Oncology", "Ophthalmology",
  "Orthopaedics", "Paediatrics", "Psychiatry", "Pulmonology", "Urology",
];

function NewConsultScreen({ onBack, onSubmitted, theme, onThemeToggle, onLogout }: {
  onBack: () => void; onSubmitted: (consultId: string) => void;
  theme: Theme; onThemeToggle: () => void; onLogout: () => void;
}) {
  const [form, setForm] = useState<ConsultForm>(EMPTY_CONSULT_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  function upd(k: keyof ConsultForm) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      setForm(p => ({ ...p, [k]: e.target.value }));
      setErrors(p => ({ ...p, [k]: "" }));
    };
  }

  function validate() {
    const e: Record<string, string> = {};
    if (!form.surname.trim())          e.surname          = "Patient surname is required";
    if (!form.givenNames.trim())       e.givenNames       = "Given name(s) are required";
    if (!form.age.trim())              e.age              = "Age is required";
    if (!form.sex)                     e.sex              = "Please select the patient's sex";
    if (!form.specialty)               e.specialty        = "Please select the specialty pool";
    if (!form.urgency)                 e.urgency          = "Please select urgency";
    if (!form.clinicalQuestion.trim()) e.clinicalQuestion = "Clinical question is required — what advice are you seeking?";
    if (!form.clinicianName.trim())    e.clinicianName    = "Your name is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) { toast.error("Please fix the highlighted fields."); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setLoading(false);
    const id = `CON-${Math.floor(Math.random() * 9000 + 1000)}`;
    toast.success("Consult request sent to the specialist pool!");
    onSubmitted(id);
  }

  return (
    <AppShell theme={theme} onThemeToggle={onThemeToggle} title="New Consult Request"
      onBack={onBack} onLogout={onLogout}>
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">

        <AlertBox type="info">
          This consult goes into a shared specialty pool. A specialist will respond asynchronously — usually within 30–60 minutes. For life-threatening emergencies, refer directly or call 112.
        </AlertBox>

        {/* Patient */}
        <Card className="p-5">
          <SectionLabel>Patient</SectionLabel>
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Surname" required error={errors.surname}>
                <Input placeholder="e.g. Adeyemi" value={form.surname} onChange={upd("surname")} />
              </Field>
              <Field label="Other Names" required error={errors.givenNames}>
                <Input placeholder="e.g. Chukwuemeka" value={form.givenNames} onChange={upd("givenNames")} />
              </Field>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <Field label="Age" required error={errors.age}>
                <Input placeholder="e.g. 34" value={form.age} onChange={upd("age")} />
              </Field>
              <Field label="Sex" required error={errors.sex}>
                <Select value={form.sex} onChange={upd("sex")} aria-invalid={!!errors.sex}>
                  <option value="">Select…</option>
                  <option value="M">Male</option>
                  <option value="F">Female</option>
                </Select>
              </Field>
              <Field label="Phone">
                <Input type="tel" placeholder="+234…" value={form.phone} onChange={upd("phone")} />
              </Field>
            </div>
          </div>
        </Card>

        {/* Specialty pool + urgency */}
        <Card className="p-5">
          <SectionLabel>Specialty Pool &amp; Urgency</SectionLabel>
          <div className="flex flex-col gap-4">
            <Field label="Specialty Needed" required error={errors.specialty}
              hint="Your request will drop into this specialty's shared pool">
              <Select value={form.specialty} onChange={upd("specialty")} aria-invalid={!!errors.specialty}>
                <option value="">Select specialty…</option>
                {CONSULT_SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
              </Select>
            </Field>

            <div>
              <label className="text-sm font-semibold text-foreground block mb-2">
                Urgency <span className="text-destructive ml-1">*</span>
              </label>
              {errors.urgency && <p className="text-xs text-destructive mb-2 flex items-center gap-1"><TriangleAlert size={12}/>{errors.urgency}</p>}
              <div className="flex flex-col gap-2">
                {([
                  { value: "ROUTINE",   label: "Routine",   sub: "Response within 24–48 hours is acceptable" },
                  { value: "URGENT",    label: "Urgent",    sub: "Needs specialist input within 2–4 hours" },
                  { value: "IMMEDIATE", label: "Immediate", sub: "Critical — also consider direct referral now" },
                ] as { value: UrgencyLevel; label: string; sub: string }[]).map(opt => {
                  const cfg = URGENCY_CONFIG[opt.value];
                  const sel = form.urgency === opt.value;
                  return (
                    <label key={opt.value}
                      className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                        sel ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
                      }`}>
                      <input type="radio" name="urgency" value={opt.value} checked={sel}
                        onChange={() => { setForm(p => ({ ...p, urgency: opt.value })); setErrors(p => ({ ...p, urgency: "" })); }}
                        className="sr-only" />
                      <div className={`size-4 rounded-full border-2 flex items-center justify-center shrink-0 ${sel ? "border-primary" : "border-muted-foreground"}`}>
                        {sel && <div className="size-2 rounded-full bg-primary" />}
                      </div>
                      <div>
                        <UrgencyBadge level={opt.value} />
                        <p className="text-[11px] text-muted-foreground mt-0.5">{opt.sub}</p>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </Card>

        {/* Clinical question */}
        <Card className="p-5">
          <SectionLabel>Clinical Question</SectionLabel>
          <div className="flex flex-col gap-4">
            <Field label="What advice are you seeking?" required error={errors.clinicalQuestion}
              hint="Be specific. State what you've tried and what decision you need help making.">
              <Textarea
                placeholder="e.g. Patient is 36 weeks pregnant with BP 145/95 and proteinuria ++. Is this pre-eclampsia? Can we manage locally with MgSO4 or does she need immediate transfer?"
                value={form.clinicalQuestion} rows={4}
                onChange={upd("clinicalQuestion")} aria-invalid={!!errors.clinicalQuestion} />
            </Field>
            <Field label="Relevant Clinical History"
              hint="PMH, medications, allergies, relevant background">
              <Textarea
                placeholder="e.g. Known hypertensive for 3 years. On amlodipine 5mg OD. No previous obstetric complications."
                value={form.clinicalHistory} rows={3}
                onChange={upd("clinicalHistory")} />
            </Field>
            <Field label="Investigations Done &amp; Results"
              hint="Any labs, ECGs, imaging results available">
              <Textarea
                placeholder="e.g. BP ×3: 148/96, 145/95, 152/98. Urine protein ++. FBC sent, awaiting result."
                value={form.investigations} rows={2}
                onChange={upd("investigations")} />
            </Field>
            <Field label="Treatment Already Given">
              <Textarea
                placeholder="e.g. MgSO4 loading dose started. Labetalol 200mg PO given."
                value={form.treatmentGiven} rows={2}
                onChange={upd("treatmentGiven")} />
            </Field>
          </div>
        </Card>

        {/* Requesting clinician */}
        <Card className="p-5">
          <SectionLabel>Requesting Clinician</SectionLabel>
          <Field label="Your Full Name" required error={errors.clinicianName}>
            <Input placeholder="e.g. Dr. Ngozi Obi" value={form.clinicianName} onChange={upd("clinicianName")} />
          </Field>
        </Card>

        <Btn type="submit" size="lg" loading={loading}>
          {loading ? "Sending to Specialist Pool…" : <><Video size={16} /> Submit Consult Request</>}
        </Btn>

      </form>
    </AppShell>
  );
}

// ─── Root App & Router ────────────────────────────────────────────────────────
export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    try { return (localStorage.getItem("mediroute-theme") as Theme) || "dark"; } catch { return "dark"; }
  });
  const [screen, setScreen] = useState<Screen>({ id: "login" });
  const [draft, setDraft] = useState<ReferralDraft | null>(null);
  const [currentUser, setCurrentUser] = useState("");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    try { localStorage.setItem("mediroute-theme", theme); } catch {}
  }, [theme]);

  // Check for saved draft
  useEffect(() => {
    try {
      const saved = localStorage.getItem("mediroute-draft");
      if (saved) setDraft(JSON.parse(saved));
    } catch {}
  }, []);

  function toggleTheme() { setTheme(t => t === "dark" ? "light" : "dark"); }
  function logout() {
    setScreen({ id: "login" });
    toast.success("You have been signed out safely.");
  }

  const themeProps = { theme, onThemeToggle: toggleTheme };

  function renderScreen() {
    if (screen.id === "login") return (
      <LoginScreen {...themeProps}
        onLogin={(u) => { setCurrentUser(u); setScreen({ id: "dashboard" }); }}
        onForgotPassword={() => setScreen({ id: "forgot-password" })}
        onCreateAccount={() => setScreen({ id: "create-account" })}
      />
    );
    if (screen.id === "forgot-password") return (
      <ForgotPasswordScreen {...themeProps} onBack={() => setScreen({ id: "login" })} />
    );
    if (screen.id === "create-account") return (
      <CreateAccountScreen {...themeProps}
        onBack={() => setScreen({ id: "login" })}
        onSuccess={email => setScreen({ id: "verify-email", email })}
      />
    );
    if (screen.id === "verify-email") return (
      <VerifyEmailScreen {...themeProps} email={screen.email}
        onBack={() => setScreen({ id: "create-account" })}
        onVerified={() => setScreen({ id: "account-success" })}
      />
    );
    if (screen.id === "account-success") return (
      <AccountSuccessScreen {...themeProps} onLogin={() => setScreen({ id: "login" })} />
    );
    if (screen.id === "dashboard") return (
      <DashboardScreen {...themeProps} onLogout={logout} username={currentUser}
        onNewReferral={() => setScreen({ id: "refer-patient", step: 1 })}
        onViewDetail={id => setScreen({ id: "referral-detail", referralId: id })}
        onManageReferrals={() => setScreen({ id: "manage-referrals" })}
        onNewConsult={() => setScreen({ id: "new-consult" })}
        onViewConsult={id => setScreen({ id: "consult-thread", consultId: id })}
        onOpenConsultInbox={() => setScreen({ id: "consult-inbox" })}
      />
    );
    if (screen.id === "refer-patient") return (
      <ReferPatientFlow {...themeProps} onLogout={logout} initialStep={screen.step}
        onDone={id => setScreen({ id: "referral-submitted", referralId: id })}
        onCancel={() => setScreen({ id: "dashboard" })}
      />
    );
    if (screen.id === "referral-submitted") return (
      <ReferralSubmittedScreen {...themeProps} onLogout={logout} referralId={screen.referralId}
        onNewReferral={() => setScreen({ id: "refer-patient", step: 1 })}
        onManage={() => setScreen({ id: "manage-referrals" })}
      />
    );
    if (screen.id === "manage-referrals") return (
      <ManageReferralsScreen {...themeProps} onLogout={logout}
        onViewDetail={id => setScreen({ id: "referral-detail", referralId: id })}
        onBack={() => setScreen({ id: "dashboard" })}
      />
    );
    if (screen.id === "referral-detail") return (
      <ReferralDetailScreen {...themeProps} onLogout={logout} referralId={screen.referralId}
        onBack={() => setScreen({ id: "dashboard" })}
      />
    );
    function convertConsult(c: Consult) {
      try {
        const pre = {
          ...EMPTY_DRAFT,
          surname: c.patient.name.split(" ").slice(-1)[0] ?? "",
          givenNames: c.patient.name.split(" ").slice(0, -1).join(" ") ?? "",
          sex: c.patient.sex, phone: c.patient.phone ?? "",
          specialtyNeeded: c.specialty, chiefComplaint: c.clinicalQuestion,
          historyOfPresentingIllness: c.clinicalHistory ?? "",
          investigations: c.investigations ?? "", urgency: c.urgency,
        };
        localStorage.setItem("mediroute-draft", JSON.stringify(pre));
      } catch {}
      toast.info("Consult converted — referral form pre-filled.");
      setScreen({ id: "refer-patient", step: 1 });
    }

    if (screen.id === "consult-inbox") return (
      <ConsultWorkspaceScreen {...themeProps} onLogout={logout} username={currentUser}
        onNewConsult={() => setScreen({ id: "new-consult" })}
        onBack={() => setScreen({ id: "dashboard" })}
        onConvertToReferral={convertConsult}
      />
    );
    if (screen.id === "consult-thread") return (
      <ConsultWorkspaceScreen {...themeProps} onLogout={logout} username={currentUser}
        consultId={screen.consultId}
        onNewConsult={() => setScreen({ id: "new-consult" })}
        onBack={() => setScreen({ id: "consult-inbox" })}
        onConvertToReferral={convertConsult}
      />
    );
    if (screen.id === "new-consult") return (
      <NewConsultScreen {...themeProps} onLogout={logout}
        onBack={() => setScreen({ id: "consult-inbox" })}
        onSubmitted={id => setScreen({ id: "consult-thread", consultId: id })}
      />
    );
    return null;
  }

  return (
    <>
      {renderScreen()}
      <Toaster position="top-center" richColors closeButton />
    </>
  );
}
