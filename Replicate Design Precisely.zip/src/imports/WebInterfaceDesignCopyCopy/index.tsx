import svgPaths from "./svg-acz6gm31eb";

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p203476e0} id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 8H3.33333" id="Vector_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_14_1089)" id="Icon">
          <path d={svgPaths.p132cf580} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_14_1089">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0 size-[28px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[107.448px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#e2e8f0] text-[16px] top-[-1px] tracking-[-0.32px] whitespace-nowrap">MediRoute NG</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container2 />
        <Text />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[132px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#64748b] text-[11px] top-[-0.33px] whitespace-nowrap">/ REFERRING PROVIDER</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Button />
        <Container1 />
        <Text1 />
      </div>
    </div>
  );
}

function Text2() {
  return <div className="bg-[#00c875] relative rounded-[22369600px] shrink-0 size-[6px]" data-name="Text" />;
}

function Text3() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[72.615px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#64748b] text-[11px] top-[-0.33px] whitespace-nowrap">LUTH · LUTH</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text2 />
        <Text3 />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#0b0f14] relative shrink-0 w-full" data-name="Header">
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[16.667px] pt-[16px] px-[24px] relative size-full">
          <Container />
          <Container3 />
        </div>
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[43px] relative shrink-0 w-[53.24px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Bold',sans-serif] font-bold leading-[38.4px] not-italic relative shrink-0 text-[#e2e8f0] text-[25.6px] tracking-[-0.64px] whitespace-nowrap">Luth</p>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icon">
          <path d="M3.125 7.5H11.875" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d="M7.5 3.125V11.875" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[16px] py-[8px] relative size-full">
        <Icon2 />
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20.4px] not-italic relative shrink-0 text-[13.6px] text-center text-white whitespace-nowrap">New Request</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between relative size-full">
        <Heading />
        <Button1 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[42px] not-italic relative shrink-0 text-[#f6a623] text-[28px] whitespace-nowrap">2</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[22px] relative shrink-0 w-[169.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#64748b] text-[11.52px] tracking-[0.3456px] whitespace-nowrap">Active Referrals</p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute bg-[#111720] content-stretch flex flex-col h-[96.615px] items-start left-0 p-[16.667px] rounded-[4px] top-0 w-[203px]" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container8 />
      <Container9 />
    </div>
  );
}

function Container11() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[42px] not-italic relative shrink-0 text-[#00c875] text-[28px] whitespace-nowrap">4</p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[22px] relative shrink-0 w-[169.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#64748b] text-[11.52px] tracking-[0.3456px] whitespace-nowrap">Accepted Today</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute bg-[#111720] content-stretch flex flex-col h-[96.615px] items-start left-[215px] p-[16.667px] rounded-[4px] top-0 w-[203px]" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container11 />
      <Container12 />
    </div>
  );
}

function Container14() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[42px] not-italic relative shrink-0 text-[#1d6ef5] text-[28px] whitespace-nowrap">3</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[22px] relative shrink-0 w-[169.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#64748b] text-[11.52px] tracking-[0.3456px] whitespace-nowrap">Arrived Today</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute bg-[#111720] content-stretch flex flex-col h-[96.615px] items-start left-[430px] p-[16.667px] rounded-[4px] top-0 w-[203px]" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container14 />
      <Container15 />
    </div>
  );
}

function Container17() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[42px] not-italic relative shrink-0 text-[#a78bfa] text-[28px] whitespace-nowrap">1</p>
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[22px] relative shrink-0 w-[169.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#64748b] text-[11.52px] tracking-[0.3456px] whitespace-nowrap">Open Consults</p>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute bg-[#111720] content-stretch flex flex-col h-[96.615px] items-start left-[645px] p-[16.667px] rounded-[4px] top-0 w-[203px]" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container17 />
      <Container18 />
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[96.615px] relative shrink-0 w-full" data-name="Container">
      <Container7 />
      <Container10 />
      <Container13 />
      <Container16 />
    </div>
  );
}

function ContainerMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[32px] relative size-full">
        <Container6 />
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[15px] relative shrink-0 w-[108.802px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] tracking-[0.8px] whitespace-nowrap">ACTIVE REFERRALS</p>
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="bg-[#1a2235] h-[17.5px] relative rounded-[4px] shrink-0 w-[17.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#64748b] text-[9px] top-[1.67px] whitespace-nowrap">3</p>
      </div>
    </div>
  );
}

function SectionHeader() {
  return (
    <div className="relative shrink-0 w-full" data-name="SectionHeader">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text4 />
        <Text5 />
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="bg-[rgba(229,62,62,0.13)] h-[17.5px] relative rounded-[4px] shrink-0 w-[59.521px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#e53e3e] text-[9px] top-[1.67px] tracking-[0.54px] whitespace-nowrap">CRITICAL</p>
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">REF-0041</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text6 />
        <Text7 />
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[26px] relative shrink-0 w-[726.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[#e2e8f0] text-[14.4px] whitespace-nowrap">A.O., 34F — Cardiology</p>
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[21px] relative shrink-0 w-[726.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] whitespace-nowrap">UNTH Enugu · 14 min ago</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[11px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_14_1081)" id="Icon">
          <path d={svgPaths.p1f658e00} id="Vector" stroke="var(--stroke-0, #F6A623)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p105d7900} id="Vector_2" stroke="var(--stroke-0, #F6A623)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_14_1081">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container27() {
  return (
    <div className="h-[22px] relative shrink-0 w-[726.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center pt-[4px] relative size-full">
        <Icon3 />
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18px] not-italic relative shrink-0 text-[#f6a623] text-[12px] whitespace-nowrap">2h 46m remaining</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="flex-[727.365_0_0] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container24 />
        <Container25 />
        <Container26 />
        <Container27 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_14_1073)" id="Icon">
          <path d={svgPaths.p23551518} id="Vector" stroke="var(--stroke-0, #00C875)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.5 5.5L6 7L11 2" id="Vector_2" stroke="var(--stroke-0, #00C875)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_14_1073">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function StatusBadge() {
  return (
    <div className="relative shrink-0" data-name="StatusBadge">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <Icon4 />
        <p className="[word-break:break-word] font-['DM_Mono:Regular',sans-serif] leading-[17.28px] not-italic relative shrink-0 text-[#00c875] text-[11.52px] whitespace-nowrap">ACCEPTED</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="bg-[#111720] relative rounded-[4px] shrink-0" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start p-[16.667px] relative size-full">
        <Container23 />
        <StatusBadge />
      </div>
    </div>
  );
}

function Text8() {
  return (
    <div className="bg-[rgba(246,166,35,0.13)] h-[17.5px] relative rounded-[4px] shrink-0 w-[47.646px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#f6a623] text-[9px] top-[1.67px] tracking-[0.54px] whitespace-nowrap">URGENT</p>
      </div>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">REF-0039</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text8 />
        <Text9 />
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="h-[26px] relative shrink-0 w-[733.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[#e2e8f0] text-[14.4px] whitespace-nowrap">B.C., 7M — Paediatrics</p>
      </div>
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[21px] relative shrink-0 w-[733.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] whitespace-nowrap">Broadcasting… · 31 min ago</p>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="flex-[734.281_0_0] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container30 />
        <Container31 />
        <Container32 />
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_14_1077)" id="Icon">
          <path d={svgPaths.p3e7757b0} id="Vector" stroke="var(--stroke-0, #F6A623)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6 3V6L8 7" id="Vector_2" stroke="var(--stroke-0, #F6A623)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_14_1077">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function StatusBadge1() {
  return (
    <div className="relative shrink-0" data-name="StatusBadge">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <Icon5 />
        <p className="[word-break:break-word] font-['DM_Mono:Regular',sans-serif] leading-[17.28px] not-italic relative shrink-0 text-[#f6a623] text-[11.52px] whitespace-nowrap">PENDING</p>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div className="bg-[#111720] relative rounded-[4px] shrink-0" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start p-[16.667px] relative size-full">
        <Container29 />
        <StatusBadge1 />
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="bg-[rgba(246,166,35,0.13)] h-[17.5px] relative rounded-[4px] shrink-0 w-[47.646px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#f6a623] text-[9px] top-[1.67px] tracking-[0.54px] whitespace-nowrap">URGENT</p>
      </div>
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">REF-0037</p>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text10 />
        <Text11 />
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="h-[26px] relative shrink-0 w-[733.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[#e2e8f0] text-[14.4px] whitespace-nowrap">E.N., 61M — Neurosurgery</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[21px] relative shrink-0 w-[733.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] whitespace-nowrap">Enugu State Hosp. · 2h ago</p>
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="flex-[734.281_0_0] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container35 />
        <Container36 />
        <Container37 />
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_14_1069)" id="Icon">
          <path d={svgPaths.p23551518} id="Vector" stroke="var(--stroke-0, #1D6EF5)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.5 5.5L6 7L11 2" id="Vector_2" stroke="var(--stroke-0, #1D6EF5)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_14_1069">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function StatusBadge2() {
  return (
    <div className="relative shrink-0" data-name="StatusBadge">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <Icon6 />
        <p className="[word-break:break-word] font-['DM_Mono:Regular',sans-serif] leading-[17.28px] not-italic relative shrink-0 text-[#1d6ef5] text-[11.52px] whitespace-nowrap">ARRIVED</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="bg-[#111720] relative rounded-[4px] shrink-0" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start p-[16.667px] relative size-full">
        <Container34 />
        <StatusBadge2 />
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[343.5px] relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-start pt-[12px] relative size-full">
        <Container22 />
        <Container28 />
        <Container33 />
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex flex-col h-[358.938px] items-start left-0 top-0 w-[848px]" data-name="Container">
      <SectionHeader />
      <Container21 />
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[15px] relative shrink-0 w-[88.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] tracking-[0.8px] whitespace-nowrap">TELE-CONSULTS</p>
      </div>
    </div>
  );
}

function Text13() {
  return (
    <div className="bg-[#1a2235] h-[17.5px] relative rounded-[4px] shrink-0 w-[17.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#64748b] text-[9px] top-[1.67px] whitespace-nowrap">2</p>
      </div>
    </div>
  );
}

function SectionHeader1() {
  return (
    <div className="relative shrink-0" data-name="SectionHeader">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text12 />
        <Text13 />
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18px] not-italic relative shrink-0 text-[#64748b] text-[12px] text-center whitespace-nowrap">{`View all `}</p>
        <Icon7 />
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between relative size-full">
        <SectionHeader1 />
        <Button2 />
      </div>
    </div>
  );
}

function Text14() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">CON-0022</p>
      </div>
    </div>
  );
}

function Text15() {
  return (
    <div className="h-[13.5px] relative shrink-0 w-[43.208px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[13.5px] left-0 not-italic text-[#00c875] text-[9px] top-[-0.33px] whitespace-nowrap">RESOLVED</p>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between relative size-full">
        <Text14 />
        <Text15 />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[25px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20.4px] not-italic relative shrink-0 text-[#e2e8f0] text-[13.6px] whitespace-nowrap">F.U., 28F — Obstetrics</p>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[11px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_14_1059)" id="Icon">
          <path d={svgPaths.p1c46400} id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_14_1059">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IconMargin() {
  return (
    <div className="relative shrink-0" data-name="Icon (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start pt-[2px] relative size-full">
        <Icon8 />
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[22px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-start pt-[4px] relative size-full">
        <IconMargin />
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18px] not-italic relative shrink-0 text-[#64748b] text-[12px] whitespace-nowrap">Specialist advised: manage locally with oxytocin protocol</p>
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="h-[21px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[#64748b] text-[11.2px] whitespace-nowrap">45 min ago</p>
      </div>
    </div>
  );
}

function Container41() {
  return (
    <div className="bg-[#111720] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start p-[16.667px] relative size-full">
        <Container42 />
        <Container43 />
        <Container44 />
        <Container45 />
      </div>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">CON-0021</p>
      </div>
    </div>
  );
}

function Text17() {
  return (
    <div className="h-[13.5px] relative shrink-0 w-[43.208px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[13.5px] left-0 not-italic text-[#f6a623] text-[9px] top-[-0.33px] whitespace-nowrap">AWAITING</p>
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between relative size-full">
        <Text16 />
        <Text17 />
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="h-[25px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20.4px] not-italic relative shrink-0 text-[#e2e8f0] text-[13.6px] whitespace-nowrap">K.A., 55M — Internal Medicine</p>
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[11px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_14_1059)" id="Icon">
          <path d={svgPaths.p1c46400} id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_14_1059">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IconMargin1() {
  return (
    <div className="relative shrink-0" data-name="Icon (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start pt-[2px] relative size-full">
        <Icon9 />
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div className="h-[22px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-start pt-[4px] relative size-full">
        <IconMargin1 />
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18px] not-italic relative shrink-0 text-[#64748b] text-[12px] whitespace-nowrap">Awaiting specialist response…</p>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="h-[21px] relative shrink-0 w-[814.667px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[4px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[#64748b] text-[11.2px] whitespace-nowrap">1h ago</p>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="bg-[#111720] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start p-[16.667px] relative size-full">
        <Container47 />
        <Container48 />
        <Container49 />
        <Container50 />
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[252.667px] relative shrink-0 w-[848px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-start pt-[12px] relative size-full">
        <Container41 />
        <Container46 />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M2.91667 7H11.0833" id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 2.91667V11.0833" id="Vector_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="content-stretch flex gap-[8px] h-[53.021px] items-center justify-center p-[16.667px] relative rounded-[4px] shrink-0 w-[848px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-dashed inset-0 pointer-events-none rounded-[4px]" />
      <Icon10 />
      <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[19.68px] not-italic relative shrink-0 text-[#64748b] text-[13.12px] text-center whitespace-nowrap">New consult or referral</p>
    </div>
  );
}

function ButtonMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Button (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[16px] relative size-full">
        <Button3 />
      </div>
    </div>
  );
}

function Container38() {
  return (
    <div className="absolute content-stretch flex flex-col h-[338.083px] items-start left-0 top-[382.94px] w-[848px]" data-name="Container">
      <Container39 />
      <Container40 />
      <ButtonMargin />
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[721.021px] relative shrink-0 w-full" data-name="Container">
      <Container20 />
      <Container38 />
    </div>
  );
}

function ContainerMargin1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[32px] relative size-full">
        <Container19 />
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="max-w-[1024px] relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] px-[24px] py-[32px] relative size-full">
        <Container5 />
        <ContainerMargin />
        <ContainerMargin1 />
      </div>
    </div>
  );
}

function ProviderDashboard() {
  return (
    <div className="bg-[#0b0f14] min-h-[537.3330078125px] relative shrink-0 w-full" data-name="ProviderDashboard">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start min-h-[inherit] relative size-full">
        <Header />
        <Container4 />
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="h-[537.333px] relative shrink-0 w-[896px]" data-name="App">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <ProviderDashboard />
      </div>
    </div>
  );
}

export default function WebInterfaceDesignCopyCopy() {
  return (
    <div className="bg-[#0b0f14] content-stretch flex flex-col items-start relative size-full" data-name="Web Interface Design (Copy) (Copy)">
      <App />
    </div>
  );
}