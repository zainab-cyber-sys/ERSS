import svgPaths from "./svg-zqs5wqx3i4";
import { imgGroup } from "./svg-cyn2n";

function Group() {
  return (
    <div className="absolute inset-[8.33%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1.25px_-1.25px] mask-size-[15px_15px]" style={{ maskImage: `url("${imgGroup}")` }} data-name="Group">
      <div className="absolute inset-[-5%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.75 13.75">
          <g id="Group">
            <path d={svgPaths.p6294f90} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-0" data-name="Clip path group">
      <Group />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <ClipPathGroup />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[25.198px] relative shrink-0 w-[113.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[0] left-0 not-italic text-[#e2e8f0] text-[0px] top-[-1px] tracking-[-0.336px] whitespace-nowrap">
          <span className="leading-[25.2px] text-[16.8px]">{`MediRoute `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal leading-[25.2px] text-[#64748b] text-[16.8px]">NG</span>
        </p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center pb-[40px] relative size-full">
        <Container2 />
        <Text />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[40.792px] relative shrink-0 w-[301.604px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[40.8px] left-[151.5px] not-italic text-[#1a2235] text-[27.2px] text-center top-[-0.67px] tracking-[-0.816px] whitespace-nowrap">Sign in to MediRoute NG</p>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[20.406px] relative shrink-0 w-[176.646px]" data-name="Paragraph">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.4px] left-[88.5px] not-italic text-[#64748b] text-[13.6px] text-center top-[-0.67px] whitespace-nowrap">Enter your credentials to access the platform</p>
    </div>
  );
}

function ParagraphMargin() {
  return (
    <div className="relative shrink-0" data-name="Paragraph (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col h-[69.198px] items-center relative shrink-0 w-full" data-name="Container">
      <Heading />
      <ParagraphMargin />
    </div>
  );
}

function Label() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Label">
      <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[15px] not-italic relative shrink-0 text-[#64748b] text-[10px] tracking-[0.8px] whitespace-nowrap">USERNAME OR FACILITY ID</p>
    </div>
  );
}

function LabelMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Label (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[8px] relative size-full">
        <Label />
      </div>
    </div>
  );
}

function Auth1() {
  return (
    <div className="bg-[#1a2235] h-[42.458px] relative rounded-[4px] shrink-0 w-[354.667px]" data-name="Auth">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center overflow-clip px-[12.667px] py-[10.667px] relative rounded-[inherit] size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#64748b] text-[14.08px] w-full">e.g. awgu-phc-001</p>
      </div>
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function FormField() {
  return (
    <div className="relative shrink-0 w-full" data-name="FormField">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <LabelMargin />
        <Auth1 />
      </div>
    </div>
  );
}

function Label1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Label">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Medium',sans-serif] leading-[15px] not-italic relative shrink-0 text-[#64748b] text-[10px] tracking-[0.8px] whitespace-nowrap">PASSWORD</p>
      </div>
    </div>
  );
}

function PasswordInput() {
  return (
    <div className="absolute bg-[#1a2235] h-[42.458px] left-0 rounded-[4px] top-0 w-[354.667px]" data-name="Password Input">
      <div className="content-stretch flex flex-col items-start justify-center overflow-clip pl-[12.667px] pr-[40.667px] py-[10.667px] relative rounded-[inherit] size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#64748b] text-[14.08px] w-full">Enter your password</p>
      </div>
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icon">
          <path d={svgPaths.p231fe800} id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          <path d={svgPaths.p66e3e00} id="Vector_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute content-stretch flex flex-col items-start justify-center left-[327.67px] top-[13.73px]" data-name="Button">
      <Icon1 />
    </div>
  );
}

function Auth2() {
  return (
    <div className="h-[42.458px] relative shrink-0 w-full" data-name="Auth">
      <PasswordInput />
      <Button />
    </div>
  );
}

function AuthMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Auth (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] relative size-full">
        <Auth2 />
      </div>
    </div>
  );
}

function FormField1() {
  return (
    <div className="relative shrink-0 w-full" data-name="FormField">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Label1 />
        <AuthMargin />
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#1d6ef5] content-stretch flex flex-col items-center justify-center py-[12px] relative rounded-[4px] shrink-0 w-[354.667px]" data-name="Button">
      <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[14.4px] text-center text-white whitespace-nowrap">Sign In</p>
    </div>
  );
}

function ButtonMargin() {
  return (
    <div className="relative shrink-0" data-name="Button (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] relative size-full">
        <Button1 />
      </div>
    </div>
  );
}

function Auth() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[229px] items-start pt-[12px] relative shrink-0 w-full" data-name="Auth">
      <FormField />
      <FormField1 />
      <ButtonMargin />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col h-[229px] items-start relative shrink-0 w-full">
      <Auth />
    </div>
  );
}

function Button2() {
  return (
    <div className="relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] text-center whitespace-nowrap">Forgot password?</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18.72px] not-italic relative shrink-0 text-[#1d6ef5] text-[12.48px] text-center whitespace-nowrap">Create facility account →</p>
      </div>
    </div>
  );
}

function Auth3() {
  return (
    <div className="content-stretch flex h-[43px] items-center justify-between pt-[24px] relative shrink-0 w-full" data-name="Auth">
      <Button2 />
      <Button3 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-[357px]">
      <Frame4 />
      <Auth3 />
    </div>
  );
}

function Container6() {
  return <div className="bg-[#1a2235] flex-[159.521_0_0] h-px min-w-px relative" data-name="Container" />;
}

function Text1() {
  return (
    <div className="h-[18px] relative shrink-0 w-[11.625px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#64748b] text-[12px] top-px whitespace-nowrap">or</p>
      </div>
    </div>
  );
}

function Container7() {
  return <div className="bg-[#1a2235] flex-[159.521_0_0] h-px min-w-px relative" data-name="Container" />;
}

function Container5() {
  return (
    <div className="content-stretch flex gap-[12px] h-[42px] items-center justify-center pt-[24px] relative shrink-0 w-full" data-name="Container">
      <Container6 />
      <Text1 />
      <Container7 />
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[21.969px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[11px] not-italic text-[#0a0a0a] text-[16px] text-center top-[-1.67px] whitespace-nowrap">🚨</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[21px] relative shrink-0 w-[291px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[21.12px] left-[144px] not-italic text-[14.08px] text-[rgba(100,116,139,0.6)] text-center top-0 whitespace-nowrap">I need a hospital now — View public status</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative rounded-[4px] shrink-0 w-full" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center px-[16.667px] py-[12.667px] relative size-full">
          <Text2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[30px] relative shrink-0 w-[354.667px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center pt-[12px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#64748b] text-[11.52px] text-center whitespace-nowrap">No login required for the public hospital status page</p>
      </div>
    </div>
  );
}

function ContainerMargin() {
  return (
    <div className="content-stretch flex flex-col h-[103.333px] items-center justify-center pt-[24px] relative shrink-0 w-[354.667px]" data-name="Container (margin)">
      <Button4 />
      <Paragraph1 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <Container5 />
      <ContainerMargin />
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[115.292px]" data-name="Button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.5px] left-[58px] not-italic text-[#1d6ef5] text-[13px] text-center top-[0.33px] whitespace-nowrap">Create an account</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <Button5 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0 w-[203px]">
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] not-italic relative shrink-0 text-[#64748b] text-[13px] text-center whitespace-nowrap">{`New facility? `}</p>
      <Frame1 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center relative shrink-0 w-full">
      <Frame />
      <Frame2 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col gap-[32px] items-center relative shrink-0 w-full">
      <Frame5 />
      <Frame3 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[32px] items-start left-[calc(50%-0.5px)] top-[52px] w-[451px]">
      <Container4 />
      <Frame6 />
    </div>
  );
}

function Container3() {
  return (
    <div className="bg-white h-[731px] relative rounded-[4px] shrink-0 w-[516px]" data-name="Container">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Frame7 />
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[53.75px] max-w-[340px] relative shrink-0 w-[340px]" data-name="Paragraph">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[17.92px] left-[170px] not-italic text-[11.2px] text-center text-white top-0 w-[340px]">By creating an account, you confirm this facility is a registered healthcare provider in Nigeria. All accounts are subject to verification.</p>
    </div>
  );
}

function ParagraphMargin1() {
  return (
    <div className="relative shrink-0" data-name="Paragraph (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[24px] relative size-full">
        <Paragraph2 />
      </div>
    </div>
  );
}

export default function Container() {
  return (
    <div className="bg-[#0b0f14] content-stretch flex flex-col items-center px-[24px] py-[48px] relative size-full" data-name="Container">
      <Container1 />
      <Container3 />
      <ParagraphMargin1 />
    </div>
  );
}