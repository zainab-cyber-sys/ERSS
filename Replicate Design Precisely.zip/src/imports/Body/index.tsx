import svgPaths from "./svg-yg4fvv454f";
import { imgGroup } from "./svg-txrji";

function Group() {
  return (
    <div className="absolute inset-[8.33%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-1.25px_-1.25px] mask-size-[15px_15px]" style={{ maskImage: `url("${imgGroup}")` }} data-name="Group">
      <div className="absolute inset-[-5%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.75 13.75">
          <g id="Group">
            <path d={svgPaths.p6294f90} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-0" data-name="Clip path group">
      <Group />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <ClipPathGroup />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[25.198px] relative shrink-0 w-[113.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[0] left-0 not-italic text-[#e2e8f0] text-[0px] top-[-1px] tracking-[-0.336px] whitespace-nowrap">
          <span className="leading-[25.2px] text-[16.8px]">{`MediRoute `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal leading-[25.2px] text-[#64748b] text-[16.8px]">NG</span>
        </p>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <div className="relative shrink-0" data-name="Logo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center pb-[40px] relative size-full">
        <Container />
        <Text />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[40.792px] relative shrink-0 w-[301.604px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[40.8px] left-[151.5px] not-italic text-[#1a2235] text-[27.2px] text-center top-[-0.67px] tracking-[-0.816px] whitespace-nowrap">Welcome back</p>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[20.406px] relative shrink-0 w-[176.646px]" data-name="Paragraph">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[20.4px] left-[88.5px] not-italic text-[#111720] text-[13.6px] text-center top-[-0.67px] whitespace-nowrap">What would you like to do today?</p>
    </div>
  );
}

function ParagraphMargin() {
  return (
    <div className="relative shrink-0" data-name="Paragraph (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function RoleSelectionScreen1() {
  return (
    <div className="h-[69.198px] relative shrink-0 w-full" data-name="RoleSelectionScreen">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative size-full">
        <Heading />
        <ParagraphMargin />
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[#e2e8f0] text-[14.4px] whitespace-nowrap">Refer a Patient</p>
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="relative shrink-0 w-[319.333px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] w-[320px]">Create referral, find suitable facility, request tele-consultation</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#0d1520] relative rounded-[4px] shrink-0 w-[354.667px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center p-[17.667px] relative size-full">
        <Paragraph1 />
        <Paragraph2 />
      </div>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[21.6px] not-italic relative shrink-0 text-[#e2e8f0] text-[14.4px] whitespace-nowrap">Manage Incoming Referrals</p>
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="relative shrink-0 w-[319.333px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] w-[320px]">Review, accept, decline, and manage patients being referred to your facility</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#0d1520] relative rounded-[4px] shrink-0 w-[354.667px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center p-[17.667px] relative size-full">
        <Paragraph3 />
        <Paragraph4 />
      </div>
    </div>
  );
}

function RoleSelectionScreen2() {
  return (
    <div className="relative shrink-0 w-full" data-name="RoleSelectionScreen">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start pt-[40px] relative size-full">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Container1() {
  return <div className="bg-[#1a2235] flex-[159.521_0_0] h-px min-w-px relative" data-name="Container" />;
}

function Text1() {
  return (
    <div className="h-[18px] relative shrink-0 w-[11.625px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[#64748b] text-[12px] top-px whitespace-nowrap">or</p>
      </div>
    </div>
  );
}

function Container2() {
  return <div className="bg-[#1a2235] flex-[159.521_0_0] h-px min-w-px relative" data-name="Container" />;
}

function Divider() {
  return (
    <div className="relative shrink-0 w-full" data-name="Divider">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center pt-[24px] relative size-full">
        <Container1 />
        <Text1 />
        <Container2 />
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[21.969px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-[11px] not-italic text-[#0a0a0a] text-[16px] text-center top-[-1.67px] whitespace-nowrap">🚨</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[21.125px] relative shrink-0 w-[287.26px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[21.12px] left-[144px] not-italic text-[#1a2235] text-[14.08px] text-center top-0 whitespace-nowrap">I need a hospital now — View public status</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="relative rounded-[4px] shrink-0 w-full" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center px-[16.667px] py-[12.667px] relative size-full">
          <Text2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[30px] relative shrink-0 w-[354.667px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center pt-[12px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[17.28px] not-italic relative shrink-0 text-[#1a2235] text-[11.52px] text-center whitespace-nowrap">No login required for the public hospital status page</p>
      </div>
    </div>
  );
}

function RoleSelectionScreen3() {
  return (
    <div className="h-[103.333px] relative shrink-0 w-[354.667px]" data-name="RoleSelectionScreen">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[24px] relative size-full">
        <Button2 />
        <Paragraph5 />
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute h-[19.5px] left-[160.75px] top-0 w-[115.292px]" data-name="Button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.5px] left-[58px] not-italic text-[#1d6ef5] text-[13px] text-center top-[0.33px] whitespace-nowrap">Create an account</p>
    </div>
  );
}

function RoleSelectionScreen4() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-full" data-name="RoleSelectionScreen">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-[120.13px] not-italic text-[#64748b] text-[13px] text-center top-[0.33px] whitespace-nowrap">{`New facility? `}</p>
      <Button3 />
    </div>
  );
}

function RoleSelectionScreenMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="RoleSelectionScreen (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[20px] relative size-full">
        <RoleSelectionScreen4 />
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white max-w-[420px] relative rounded-[4px] shrink-0 w-[420px]" data-name="Card">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start max-w-[inherit] p-[32.667px] relative size-full">
        <RoleSelectionScreen1 />
        <RoleSelectionScreen2 />
        <Divider />
        <RoleSelectionScreen3 />
        <RoleSelectionScreenMargin />
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[53.75px] max-w-[340px] relative shrink-0 w-[340px]" data-name="Paragraph">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[17.92px] left-[170px] not-italic text-[#64748b] text-[11.2px] text-center top-0 w-[340px]">By creating an account, you confirm this facility is a registered healthcare provider in Nigeria. All accounts are subject to verification.</p>
    </div>
  );
}

function ParagraphMargin1() {
  return (
    <div className="relative shrink-0" data-name="Paragraph (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[24px] relative size-full">
        <Paragraph6 />
      </div>
    </div>
  );
}

function RoleSelectionScreen() {
  return (
    <div className="bg-[#0b0f14] h-[809.125px] min-h-[539.3330078125px] relative shrink-0 w-full" data-name="RoleSelectionScreen">
      <div className="flex flex-col items-center justify-center min-h-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center min-h-[inherit] px-[24px] py-[48px] relative size-full">
          <Logo />
          <Card />
          <ParagraphMargin1 />
        </div>
      </div>
    </div>
  );
}

export default function Body() {
  return (
    <div className="content-stretch flex flex-col items-start relative size-full" data-name="Body">
      <RoleSelectionScreen />
    </div>
  );
}