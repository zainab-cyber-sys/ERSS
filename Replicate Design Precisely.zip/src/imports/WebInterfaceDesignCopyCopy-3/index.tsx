import svgPaths from "./svg-qjflx56zuf";

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p203476e0} id="Vector" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 8H3.33333" id="Vector_2" stroke="var(--stroke-0, #64748B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_14_1089)" id="Icon">
          <path d={svgPaths.p132cf580} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_14_1089">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0 size-[28px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[107.448px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[24px] left-0 not-italic text-[#e2e8f0] text-[16px] top-[-1px] tracking-[-0.32px] whitespace-nowrap">MediRoute NG</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container1 />
        <Text />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[125.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#64748b] text-[11px] top-[-0.33px] whitespace-nowrap">/ TELE-CONSULT POOL</p>
      </div>
    </div>
  );
}

function Text2() {
  return <div className="bg-[#00c875] relative rounded-[22369600px] shrink-0 size-[6px]" data-name="Text" />;
}

function Text3() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[26.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[16.5px] left-0 not-italic text-[#64748b] text-[11px] top-[-0.33px] whitespace-nowrap">LUTH</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Container">
      <Text2 />
      <Text3 />
    </div>
  );
}

function ContainerAutoMarginAlignment() {
  return (
    <div className="flex-[1_0_0] min-w-px relative" data-name="Container (auto margin alignment)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-end relative size-full">
        <Container2 />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#0b0f14] relative shrink-0 w-full" data-name="Header">
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center pb-[16.667px] pt-[16px] px-[24px] relative size-full">
          <Button />
          <Container />
          <Text1 />
          <ContainerAutoMarginAlignment />
        </div>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[12.667px] pt-[12px] px-[16px] relative size-full">
        <p className="[word-break:break-word] font-['DM_Mono:Regular',sans-serif] leading-[15px] not-italic relative shrink-0 text-[#64748b] text-[10px] tracking-[0.8px] whitespace-nowrap">SPECIALTY INBOX</p>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">CON-0023</p>
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[13.5px] relative shrink-0 w-[32.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-0 not-italic text-[#f6a623] text-[9px] top-[-0.33px] whitespace-nowrap">URGENT</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex items-center justify-between left-[16px] top-[14px] w-[255.333px]" data-name="Container">
      <Text4 />
      <Text5 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute h-[19.917px] left-[16px] top-[33px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.92px] left-0 not-italic text-[#e2e8f0] text-[13.28px] top-[-0.67px] whitespace-nowrap">F.O., 22M</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute h-[17.281px] left-[16px] top-[54.92px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[17.28px] left-0 not-italic text-[#64748b] text-[11.52px] top-[-0.67px] whitespace-nowrap">Cardiology · 12 min</p>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#1a2235] border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid h-[86.865px] left-0 top-0 w-[287.333px]" data-name="Button">
      <Container5 />
      <Container6 />
      <Container7 />
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">CON-0021</p>
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[13.5px] relative shrink-0 w-[32.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-0 not-italic text-[#f6a623] text-[9px] top-[-0.33px] whitespace-nowrap">URGENT</p>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex items-center justify-between left-[16px] top-[14px] w-[255.333px]" data-name="Container">
      <Text6 />
      <Text7 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[19.917px] left-[16px] top-[33px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.92px] left-0 not-italic text-[#e2e8f0] text-[13.28px] top-[-0.67px] whitespace-nowrap">K.A., 55M</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute h-[17.281px] left-[16px] top-[54.92px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[17.28px] left-0 not-italic text-[#64748b] text-[11.52px] top-[-0.67px] whitespace-nowrap">Internal Medicine · 1h 4min</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid h-[86.865px] left-0 top-[86.86px] w-[287.333px]" data-name="Button">
      <Container8 />
      <Container9 />
      <Container10 />
    </div>
  );
}

function Text8() {
  return (
    <div className="h-[15px] relative shrink-0 w-[48px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">CON-0019</p>
      </div>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[13.5px] relative shrink-0 w-[32.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Medium',sans-serif] leading-[13.5px] left-0 not-italic text-[#00c875] text-[9px] top-[-0.33px] whitespace-nowrap">CLOSED</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute content-stretch flex items-center justify-between left-[16px] top-[14px] w-[255.333px]" data-name="Container">
      <Text8 />
      <Text9 />
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute h-[19.917px] left-[16px] top-[33px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[19.92px] left-0 not-italic text-[#e2e8f0] text-[13.28px] top-[-0.67px] whitespace-nowrap">A.B., 8F</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[17.281px] left-[16px] top-[54.92px] w-[255.333px]" data-name="Container">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium leading-[17.28px] left-0 not-italic text-[#64748b] text-[11.52px] top-[-0.67px] whitespace-nowrap">Paediatrics · 3h ago</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid h-[86.865px] left-0 top-[173.73px] w-[287.333px]" data-name="Button">
      <Container11 />
      <Container12 />
      <Container13 />
    </div>
  );
}

function InlineContent() {
  return (
    <div className="h-[428px] relative shrink-0 w-full" data-name="Inline content">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button1 />
        <Button2 />
        <Button3 />
      </div>
    </div>
  );
}

function Sidebar() {
  return (
    <div className="h-full min-w-[220px] relative shrink-0 w-[288px]" data-name="Sidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start min-w-[inherit] overflow-clip pr-[0.667px] relative rounded-[inherit] size-full">
        <Container4 />
        <InlineContent />
      </div>
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-r-[0.667px] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[22.792px] relative shrink-0 w-[172.698px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[22.8px] left-0 not-italic text-[#e2e8f0] text-[15.2px] top-0 whitespace-nowrap">F.O., 22M — Cardiology</p>
      </div>
    </div>
  );
}

function Text11() {
  return (
    <div className="bg-[rgba(246,166,35,0.13)] h-[17.5px] relative rounded-[4px] shrink-0 w-[44.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[13.5px] left-[6px] not-italic text-[#f6a623] text-[9px] top-[1.67px] whitespace-nowrap">URGENT</p>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text10 />
        <Text11 />
      </div>
    </div>
  );
}

function ContainerMargin() {
  return (
    <div className="h-[20px] relative shrink-0 w-[225.104px]" data-name="Container (margin)">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[2px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[18px] not-italic relative shrink-0 text-[#64748b] text-[12px] whitespace-nowrap">Enugu Cardiology Pool · Open 12 min</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="relative shrink-0 w-[225.104px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container16 />
        <ContainerMargin />
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative rounded-[4px] shrink-0" data-name="Button">
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center px-[12.667px] py-[6.667px] relative size-full">
        <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[18.72px] not-italic relative shrink-0 text-[#64748b] text-[12.48px] text-center whitespace-nowrap">Close thread</p>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-b-[0.667px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[16.667px] pt-[16px] px-[24px] relative size-full">
          <Container15 />
          <Button4 />
        </div>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="bg-[rgba(167,139,250,0.13)] relative rounded-[22369600px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="[word-break:break-word] font-['Inter:Bold',sans-serif] font-bold leading-[16.8px] not-italic relative shrink-0 text-[#a78bfa] text-[11.2px] whitespace-nowrap">DN</p>
      </div>
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[18.719px] relative shrink-0 w-[114.771px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[18.72px] left-0 not-italic text-[#e2e8f0] text-[12.48px] top-[-0.67px] whitespace-nowrap">Dr. Ngozi Okonkwo</p>
      </div>
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[15px] relative shrink-0 w-[126px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['DM_Mono:Regular',sans-serif] leading-[15px] left-0 not-italic text-[#64748b] text-[10px] top-[-0.33px] whitespace-nowrap">Referring PHC · 14:02</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Text12 />
        <Text13 />
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="bg-[#1a2235] h-[89.281px] relative rounded-[4px] shrink-0 w-[512px]" data-name="Container">
      <div aria-hidden className="absolute border-[#a78bfa] border-l-[2.667px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[21.76px] left-[14.67px] not-italic text-[#e2e8f0] text-[13.6px] top-[11px] w-[486px]">Patient presents with sudden chest pain, diaphoresis, and BP 88/56. ECG shows ST elevation in leads II, III, aVF. Suspected inferior STEMI. Request urgent cardiology guidance.</p>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="max-w-[512px] relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start max-w-[inherit] relative size-full">
        <Container21 />
        <Container22 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-start relative size-full">
        <Container19 />
        <Container20 />
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="flex-[306.396_0_0] min-h-px relative w-[623.333px]" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start p-[24px] relative size-full">
          <Container18 />
        </div>
      </div>
    </div>
  );
}

function TextArea() {
  return (
    <div className="bg-[#1a2235] flex-[527.333_0_0] h-[62.146px] min-w-px relative rounded-[4px]" data-name="Text Area">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start px-[12.667px] py-[10.667px] relative size-full">
          <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[20.4px] not-italic relative shrink-0 text-[#64748b] text-[13.6px] w-full">Type your response…</p>
        </div>
      </div>
      <div aria-hidden className="absolute border-[0.667px] border-[rgba(255,255,255,0.08)] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_16_1273)" id="Icon">
          <path d={svgPaths.p22f0380} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.5693 1.43133L7.276 8.724" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_16_1273">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-[#1d6ef5] relative rounded-[4px] shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center p-[10px] relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div aria-hidden className="absolute border-[rgba(255,255,255,0.08)] border-solid border-t-[0.667px] inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-end pb-[16px] pt-[16.667px] px-[24px] relative size-full">
        <TextArea />
        <Button5 />
      </div>
    </div>
  );
}

function MainContent() {
  return (
    <div className="flex-[623.333_0_0] h-full min-w-px relative" data-name="Main Content">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container14 />
        <Container17 />
        <Container23 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="flex-[476.667_0_0] min-h-px relative w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <Sidebar />
        <MainContent />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="bg-[#0b0f14] h-[537.333px] relative shrink-0 w-[911.333px]" data-name="Body">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Header />
        <Container3 />
      </div>
    </div>
  );
}

export default function WebInterfaceDesignCopyCopy() {
  return (
    <div className="bg-[#0b0f14] content-stretch flex flex-col items-start relative size-full" data-name="Web Interface Design (Copy) (Copy)">
      <Body />
    </div>
  );
}